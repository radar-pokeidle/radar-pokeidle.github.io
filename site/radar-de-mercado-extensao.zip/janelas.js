// Radar de Mercado (extensão dos jogadores) — as duas janelas flutuantes dentro do jogo.
// 1) Menu: o mesmo menu do ícone da extensão, embutido, no alto à direita (em cima das Automações do jogo).
// 2) Lista: embaixo à direita, com os anúncios avaliados (filtros) e os destaques patrocinados.
// As duas abrem e fecham no + / –, arrastam pelo topo e lembram o lugar. O conteúdo fica numa "sombra" (shadow DOM)
// para o CSS do jogo não entortar nada.
(function () {
  'use strict';
  const SITE = 'https://radar-pokeidle.github.io'; // site estático no GitHub Pages
  const ROTULO = { excepcional: '★ EXCEPCIONAL', otimo: 'ÓTIMO', bom: 'BOM', justo: 'JUSTO', caro: 'CARO', '?': 'POUCAS REFERÊNCIAS' };
  const CURTO = { excepcional: '★ EXC', otimo: 'ÓTIMO', bom: 'BOM', justo: 'JUSTO', caro: 'CARO', '?': '?' };
  const COR = { excepcional: '#b8860b', otimo: '#14833b', bom: '#2f9b5a', justo: '#6b6475', caro: '#a8323e', '?': '#4b4555' };
  const ORDEM = { excepcional: 5, otimo: 4, bom: 3, justo: 2, caro: 1, '?': 0 };
  const FILTROS = [
    ['ultimos', 'Últimos que entraram'],
    ['todos', 'Todos (melhores primeiro)'],
    ['bons', 'Bons, ótimos e excepcionais'],
    ['otimos', 'Só ótimos e excepcionais'],
  ];
  const DESTAQUES_MS = 5 * 60_000;
  const REDESENHO_MS = 15_000;
  const MARGEM = 12;
  const TOPO_PADRAO = 110;
  const MAX_LINHAS = 150;
  const GEMA_SVG =
    '<svg viewBox="0 0 16 16" width="12" height="12" style="vertical-align:-1px" aria-label="gemas"><path d="M4 2h8l3.5 4.2L8 14.5.5 6.2z" fill="#e0408c"/><path d="M4 2h8l3.5 4.2H.5z" fill="#ff7fbd"/><path d="M4 2 5.4 6.2H.5zM12 2l-1.4 4.2h4.9z" fill="#ffb0d8"/><path d="M5.4 6.2h5.2L8 14.5z" fill="#ff5aa6"/><path d="M6.4 2h3.2l1 4.2H5.4z" fill="#ffd2ea" opacity=".85"/></svg>';
  const ESTILO =
    ':host{all:initial}*{box-sizing:border-box}' +
    '.j{font:12px/1.4 system-ui,sans-serif;color:#f6ece6}' +
    'button,select{font:inherit;color:inherit;margin:0}a{text-decoration:none}a:hover{text-decoration:underline}' +
    'select{background:#2a1820;border:1px solid #57323f;border-radius:6px;padding:2px 4px;width:100%}' +
    '.linha:hover{background:#3a2230}';

  let todos = [];
  let sincronizadoEm = null;
  let destaques = [];

  const n0 = (v) => (v == null ? '—' : Math.round(v).toLocaleString('pt-BR'));
  const hora = (t) => new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  function el(tag, css, texto) {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (texto != null) e.textContent = texto;
    return e;
  }
  function gema() {
    const s = document.createElement('span');
    s.innerHTML = GEMA_SVG; // marcação fixa, sem dado de fora
    return s;
  }

  // clicar num nome põe ele na busca do Mercado da Comunidade (se a busca estiver na tela)
  function procurarNoJogo(nome) {
    const campo = document.querySelector('input[placeholder*="buscar" i]');
    if (!campo || !nome) return;
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(campo, nome);
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    campo.focus();
  }

  // ---- uma janela flutuante: sombra, posição (presa no alto ou embaixo à direita), arrastar e lembrar ----------
  function criarJanela({ id, chave, padrao, largura, larguraFechada, ancora }) {
    const j = { estado: { ...padrao }, host: null, conteudo: null, arrastando: false };
    j.montar = () => {
      if (j.host || !document.body) return;
      j.host = el('div', 'position:fixed;z-index:2147483000;background:#22131af2;border:1px solid #f0b93a66;border-radius:12px;box-shadow:0 10px 30px #000a;overflow:hidden');
      j.host.id = id;
      const sombra = j.host.attachShadow({ mode: 'open' });
      const estilo = el('style');
      estilo.textContent = ESTILO;
      j.conteudo = el('div');
      j.conteudo.className = 'j';
      sombra.append(estilo, j.conteudo);
      document.body.appendChild(j.host);
    };
    j.largura = () => (j.estado.aberta ? largura : larguraFechada);
    j.posicionar = () => {
      if (!j.host) return;
      const L = document.documentElement.clientWidth || window.innerWidth;
      const A = document.documentElement.clientHeight || window.innerHeight;
      if (!L || !A) return; // aba em segundo plano: posiciona quando ela voltar
      const w = j.host.offsetWidth || j.largura();
      const h = j.host.offsetHeight || 34;
      const x = j.estado.x == null ? L - w - MARGEM : j.estado.x;
      const y = j.estado.y == null ? (ancora === 'baixo' ? A - h - MARGEM : TOPO_PADRAO) : j.estado.y;
      j.host.style.left = `${Math.max(0, Math.min(x, L - w))}px`;
      j.host.style.top = `${Math.max(0, Math.min(y, A - 34))}px`;
    };
    j.salvar = () => chrome.storage.local.set({ [chave]: { ...j.estado } });
    j.carregar = (pronto) =>
      chrome.storage.local.get([chave], (s) => {
        j.estado = { ...padrao, ...(s[chave] || {}) };
        pronto();
      });
    j.ocupada = () => j.arrastando || (j.host && j.host.matches(':hover'));
    // topo: título, botão + / – e alça de arrastar
    j.cabecalho = (titulo, alternar) => {
      const topo = el('div', 'display:flex;align-items:center;gap:6px;padding:6px 8px;background:linear-gradient(180deg,#c06f48,#a2573a);cursor:move;font-weight:700;user-select:none;touch-action:none');
      topo.title = 'Arraste para mudar de lugar';
      topo.appendChild(el('span', 'flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis', titulo));
      const botao = el('button', 'border:0;border-radius:6px;background:#0004;color:#fff;font:700 13px/1 system-ui;width:22px;height:20px;cursor:pointer', j.estado.aberta ? '–' : '+');
      botao.title = j.estado.aberta ? 'Diminuir' : 'Aumentar';
      botao.onclick = alternar;
      topo.appendChild(botao);
      topo.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || e.target.closest('button')) return;
        const r = j.host.getBoundingClientRect();
        const dx = e.clientX - r.left;
        const dy = e.clientY - r.top;
        j.arrastando = true;
        topo.setPointerCapture(e.pointerId);
        const mover = (ev) => {
          j.estado.x = ev.clientX - dx;
          j.estado.y = ev.clientY - dy;
          j.posicionar();
        };
        const soltar = () => {
          topo.removeEventListener('pointermove', mover);
          topo.removeEventListener('pointerup', soltar);
          const r2 = j.host.getBoundingClientRect();
          j.estado.x = Math.round(r2.left);
          j.estado.y = Math.round(r2.top);
          j.arrastando = false;
          j.salvar();
        };
        topo.addEventListener('pointermove', mover);
        topo.addEventListener('pointerup', soltar);
      });
      return { topo, botao };
    };
    return j;
  }

  // ---- 1) menu: o popup.html da extensão num iframe (as mesmas opções do ícone, sempre sincronizadas) ----------
  const menu = criarJanela({ id: 'rdm-menu', chave: 'janelaMenu', padrao: { x: null, y: null, aberta: true }, largura: 320, larguraFechada: 190, ancora: 'cima' });
  let quadro = null;
  let botaoMenu = null;
  const ORIGEM_EXTENSAO = new URL(chrome.runtime.getURL('')).origin;

  function montarMenu() {
    menu.montar();
    if (!menu.host || quadro) return;
    const { topo, botao } = menu.cabecalho('📡 Radar de Mercado', () => {
      menu.estado.aberta = !menu.estado.aberta;
      menu.salvar();
      aplicarMenu();
    });
    botaoMenu = botao;
    quadro = el('iframe', 'display:block;width:100%;height:440px;border:0;background:#1c1015');
    quadro.src = chrome.runtime.getURL('popup.html?embutido=1');
    quadro.title = 'Menu do Radar de Mercado';
    menu.conteudo.append(topo, quadro);
    aplicarMenu();
  }
  function aplicarMenu() {
    // o iframe nunca sai do lugar (tirar e pôr de volta recarregaria o menu): só some quando a janela fecha
    menu.host.style.width = `${menu.largura()}px`;
    quadro.style.display = menu.estado.aberta ? 'block' : 'none';
    botaoMenu.textContent = menu.estado.aberta ? '–' : '+';
    botaoMenu.title = menu.estado.aberta ? 'Diminuir' : 'Aumentar';
    menu.posicionar();
  }
  // o menu embutido avisa a altura do conteúdo; a janela acompanha, sem passar da tela
  window.addEventListener('message', (e) => {
    if (e.origin !== ORIGEM_EXTENSAO || !quadro || typeof (e.data && e.data.rdmAltura) !== 'number') return;
    const A = document.documentElement.clientHeight || window.innerHeight || 800;
    quadro.style.height = `${Math.max(120, Math.min(e.data.rdmAltura, A - TOPO_PADRAO - 60))}px`;
    menu.posicionar();
  });

  // ---- 2) lista: anúncios avaliados com filtros, e os destaques embaixo -----------------------------------------
  const lista = criarJanela({
    id: 'rdm-lista',
    chave: 'janelaLista',
    padrao: { x: null, y: null, aberta: true, moeda: 'g', filtro: 'ultimos' },
    largura: 330,
    larguraFechada: 210,
    ancora: 'baixo',
  });

  function filtrar(e) {
    // desde a 2.0 a lista é o que a extensão viu (os novos e as páginas folheadas): só o que foi visto há pouco,
    // para não mostrar anúncio que já pode ter sido vendido
    const limite = Date.now() - 45 * 60_000;
    let xs = todos.filter((a) => a.m === e.moeda && (!a.t || a.t >= limite));
    if (e.filtro === 'bons') xs = xs.filter((a) => ORDEM[a.v] >= 3);
    if (e.filtro === 'otimos') xs = xs.filter((a) => ORDEM[a.v] >= 4);
    if (e.filtro === 'ultimos') return xs.sort((a, b) => b.id - a.id); // id maior = anúncio mais novo
    return xs.sort((a, b) => ORDEM[b.v] - ORDEM[a.v] || (b.i ?? 0) - (a.i ?? 0) || (a.vs ?? 0) - (b.vs ?? 0));
  }

  function corpoLista() {
    const e = lista.estado;
    const c = el('div', 'padding:8px 10px;display:grid;gap:6px');
    if (!todos.length) {
      c.appendChild(
        el('div', 'color:#f0b93a', '⏳ Ainda sem anúncios avaliados. O Radar avalia aqui, no seu navegador, os anúncios novos e os que você folhear no Mercado, com as vendas da Tabela de preços do jogo.'),
      );
      return c;
    }
    const abas = el('div', 'display:flex;gap:4px');
    for (const [m, nome] of [['g', 'Gemas'], ['c', 'Coins']]) {
      const b = el('button', `flex:1;border:1px solid #57323f;border-radius:999px;padding:2px 0;cursor:pointer;font-weight:600;font-size:11px;color:#fff;background:${e.moeda === m ? '#9356dc' : 'transparent'}`, nome);
      b.onclick = () => {
        e.moeda = m;
        lista.salvar();
        desenharLista(true);
      };
      abas.appendChild(b);
    }
    c.appendChild(abas);

    const filtro = el('select');
    filtro.title = 'Quais anúncios mostrar';
    for (const [valor, nome] of FILTROS) {
      const o = el('option', '', nome);
      o.value = valor;
      o.selected = e.filtro === valor;
      filtro.appendChild(o);
    }
    filtro.onchange = () => {
      e.filtro = filtro.value;
      lista.salvar();
      desenharLista(true);
    };
    c.appendChild(filtro);

    const xs = filtrar(e);
    c.appendChild(
      el('div', 'color:#93767c;font-size:11px', `${n0(xs.length)} anúncio${xs.length === 1 ? '' : 's'}${xs.length > MAX_LINHAS ? ` (mostrando ${MAX_LINHAS})` : ''}${sincronizadoEm ? ` · atualizado ${hora(sincronizadoEm)}` : ''}`),
    );
    const caixa = el('div', 'max-height:300px;overflow:auto;margin:0 -4px');
    for (const a of xs.slice(0, MAX_LINHAS)) {
      // a linha toda leva a cor do veredito, igual à etiqueta dos cards
      const cor = COR[a.v] || COR['?'];
      const linha = el('div', `display:flex;gap:6px;align-items:center;padding:4px;margin-top:2px;border-radius:6px;border-left:4px solid ${cor};background:${cor}33;cursor:pointer`);
      linha.className = 'linha';
      linha.title = `${ROTULO[a.v] || ''}${a.med ? ` · mediana ${n0(a.med)}` : ''}${a.n ? ` (${a.n} vendas)` : ''}\nClique para procurar no Mercado da Comunidade`;
      linha.onclick = () => procurarNoJogo(a.nome);
      linha.appendChild(el('span', `flex:none;min-width:46px;text-align:center;border-radius:5px;padding:0 4px;font-size:10px;font-weight:800;color:#fff;background:${COR[a.v] || COR['?']}`, CURTO[a.v] || '?'));
      linha.appendChild(el('span', 'flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis', `${a.sh ? '✨' : ''}${a.nome}`));
      linha.appendChild(el('span', 'flex:none;color:#cdb3b6', `${n0(a.p)}${a.vs != null ? ` ${globalThis.RadarCartao.pct(a.vs)}` : ''}`));
      caixa.appendChild(linha);
    }
    if (!xs.length) caixa.appendChild(el('div', 'color:#93767c;padding:4px', 'Nenhum anúncio neste filtro agora.'));
    c.appendChild(caixa);
    const link = el('a', 'color:#f0b93a', 'Mercado completo no site →');
    link.href = `${SITE}/mercado/`;
    link.target = '_blank';
    link.rel = 'noopener';
    c.appendChild(link);
    return c;
  }

  function blocoDestaques(compacto) {
    const c = el('div', 'padding:6px 8px;border-top:1px solid #f0b93a44;display:grid;gap:4px');
    if (!destaques.length) {
      if (compacto) return null;
      const vaga = el('a', 'color:#f0b93a;font-size:11px', '★ Vaga de destaque livre: anuncie o seu →');
      vaga.href = `${SITE}/destaque/`;
      vaga.target = '_blank';
      vaga.rel = 'noopener';
      c.appendChild(vaga);
      return c;
    }
    c.appendChild(el('div', 'color:#f0b93a;font-weight:700;font-size:11px', '★ Em destaque'));
    for (const d of destaques) {
      const f = d.ficha || {};
      const a = d.avaliacao;
      const card = el('div', 'border:1px solid #f0b93a55;border-radius:8px;padding:4px 7px;background:#3a2230;cursor:pointer');
      card.title = 'Clique para procurar no Mercado da Comunidade.'; // sem nick na extensão (regra do projeto)
      card.onclick = () => procurarNoJogo(f.especie);
      card.appendChild(el('div', 'font-weight:700', `${f.shiny ? '✨ ' : ''}${f.especie || '?'}`));
      if (!compacto) card.appendChild(el('div', 'color:#cdb3b6', `Nv ${n0(f.nivel)} · P${f.potencia ?? '?'} · N ${f.nota != null ? Number(f.nota).toFixed(2) : '?'}`));
      const preco = el('div', 'font-weight:700;color:#e58bff');
      preco.append(
        gema(),
        ` ${n0(d.preco)}${a && a.veredito && a.veredito !== '?' ? ` · ${ROTULO[a.veredito] || a.veredito}` : ''}${a && a.vsMercado != null ? ` ${a.vsMercado > 0 ? '+' : ''}${a.vsMercado}%` : ''}`,
      );
      card.appendChild(preco);
      c.appendChild(card);
    }
    return c;
  }

  let ultimoDesenho = 0;
  function desenharLista(forcar = false) {
    lista.montar();
    if (!lista.host || (!forcar && lista.ocupada())) return;
    const e = lista.estado;
    const bons = todos.filter((a) => a.m === e.moeda && ORDEM[a.v] >= 4).length;
    const titulo = todos.length ? `📡 Radar · ${bons} ótimo${bons === 1 ? '' : 's'}${e.moeda === 'c' ? ' (coins)' : ''}` : '📡 Radar · carregando…';
    const { topo } = lista.cabecalho(titulo, () => {
      e.aberta = !e.aberta;
      lista.salvar();
      desenharLista(true);
    });
    lista.host.style.width = `${lista.largura()}px`;
    lista.conteudo.replaceChildren(topo);
    if (e.aberta) lista.conteudo.appendChild(corpoLista());
    const d = blocoDestaques(!e.aberta);
    if (d) lista.conteudo.appendChild(d);
    lista.posicionar();
    ultimoDesenho = Date.now();
  }

  async function carregarDestaques() {
    try {
      const r = await fetch(`${SITE}/dados/destaques.json`, { cache: 'no-cache' });
      if (r.ok) destaques = (await r.json()).destaques || [];
    } catch { /* sem internet: fica o que tinha */ }
    desenharLista();
  }

  // ---- dados e ciclo ----------------------------------------------------------------------------------------------
  chrome.storage.local.get(['anuncios', 'sincronizadoEm'], (s) => {
    todos = Object.values(s.anuncios || {});
    sincronizadoEm = s.sincronizadoEm || null;
    menu.carregar(montarMenu);
    lista.carregar(() => {
      desenharLista(true);
      carregarDestaques();
    });
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.sincronizadoEm) sincronizadoEm = ch.sincronizadoEm.newValue || null;
    if (!ch.anuncios) return;
    const antes = todos.length;
    todos = Object.values(ch.anuncios.newValue || {});
    if (!antes !== !todos.length) desenharLista(true); // terminou a primeira carga: troca o aviso pela lista na hora
  });
  setInterval(carregarDestaques, DESTAQUES_MS);
  setInterval(() => {
    if (!document.hidden && Date.now() - ultimoDesenho > REDESENHO_MS) desenharLista();
  }, 3000);
  const reposicionar = () => {
    menu.posicionar();
    lista.posicionar();
  };
  window.addEventListener('resize', reposicionar);
  document.addEventListener('visibilitychange', () => !document.hidden && reposicionar());
})();
