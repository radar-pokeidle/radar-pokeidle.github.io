// Radar de Mercado (extensão dos jogadores) — etiquetas nos cards do Mercado da Comunidade e o painel.
// Liga cada card ao anúncio pelo número que o próprio jogo põe nele (data-fav) e mostra a avaliação que o local.js fez
// no navegador (desde a 2.0). Se o jogo mudar a tela, cai no jeito antigo: nível, IV total e nota escritos no card.
(function () {
  'use strict';
  const PASSO_MS = 2500; // rede de segurança; a etiqueta entra na hora pelo observador da tela
  const AVISO_MS = 60_000;

  let porId = new Map(); // número do anúncio -> anúncio avaliado
  let porChave = new Map(); // `${nivel}|${ivTotal}|${nota×100}` -> [anúncio] (reserva)
  let todos = [];
  let ligado = true;

  const chave = (nivel, iv, nota) => `${nivel}|${iv}|${Math.round(Number(nota) * 100)}`;

  function indexar(anuncios) {
    todos = Object.values(anuncios || {});
    porChave = new Map();
    porId = new Map();
    for (const a of todos) {
      porId.set(Number(a.id), a);
      if (!porChave.has(a.k)) porChave.set(a.k, []);
      porChave.get(a.k).push(a);
    }
  }
  chrome.storage.local.get(['anuncios', 'etiquetasLigadas'], (s) => {
    indexar(s.anuncios);
    ligado = s.etiquetasLigadas !== false;
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.anuncios) {
      indexar(ch.anuncios.newValue);
      agendar();
    }
    if (ch.etiquetasLigadas) ligado = ch.etiquetasLigadas.newValue !== false;
  });

  // avisa o fundo que o jogo está aberto: ele só sincroniza enquanto alguém está jogando
  const avisar = () => {
    if (!document.hidden) chrome.runtime.sendMessage({ tipo: 'jogo-aberto' }).catch(() => {});
  };
  avisar();
  setInterval(avisar, AVISO_MS);

  // ---- ponte da compra automática: o fundo manda, o gancho (dentro da página) envia e devolve o resultado -------
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.tipo === 'comprar' && msg.pedido) {
      document.dispatchEvent(new CustomEvent('rdm:comprar', { detail: JSON.stringify(msg.pedido) }));
    }
  });
  document.addEventListener('rdm:resposta', (ev) => {
    let r;
    try { r = JSON.parse(ev.detail); } catch { return; }
    chrome.runtime.sendMessage({ tipo: 'compra-resposta', r }).catch(() => {});
  });

  // ---- achar e ler os cards (mesmo jeito do radar pessoal) ----------------------------------------------------
  function botoesVerFicha() {
    const r = [];
    const it = document.evaluate("//*[normalize-space(text())='Ver ficha']", document.body, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    for (let i = 0; i < it.snapshotLength; i++) r.push(it.snapshotItem(i));
    return r;
  }
  function cardDe(botao) {
    let el = botao;
    while (el.parentElement && el.parentElement !== document.body) {
      const w = el.parentElement.getBoundingClientRect().width;
      if (w > 330 || w === 0) break;
      el = el.parentElement;
    }
    return el;
  }
  const numero = (txt) => {
    const m = /^(\d+(?:[.,]\d+)*)\s*([KkMmBb])?$/.exec(String(txt).trim());
    if (!m) return null;
    const mult = m[2] ? { k: 1e3, m: 1e6, b: 1e9 }[m[2].toLowerCase()] : 1;
    return m[2] ? Number(m[1].replace(/\./g, '').replace(',', '.')) * mult : Number(m[1].replace(/[.,]/g, ''));
  };
  function lerCard(card) {
    const texto = card.innerText;
    const linhas = texto.split('\n').map((x) => x.trim()).filter(Boolean);
    const nv = /Nv\s*([\d.]+)/.exec(texto);
    const iv = /(?:^|[^A-Za-z])IV\s*(\d+)/m.exec(texto);
    const n = /(?:^|[^A-Za-z])N\s*(\d+(?:[.,]\d+)?)(?![\d])/m.exec(texto);
    const iVer = linhas.findIndex((x) => x === 'Ver ficha');
    let preco = null;
    for (const x of linhas.slice(iVer + 1)) {
      const v = numero(x);
      if (v != null) {
        preco = v;
        break;
      }
    }
    return { nivel: nv ? Number(nv[1].replace(/\./g, '')) : null, iv: iv ? Number(iv[1]) : null, nota: n ? Number(n[1].replace(',', '.')) : null, preco };
  }
  function acharAnuncio(c) {
    const lista = porChave.get(chave(c.nivel, c.iv, c.nota));
    if (!lista || !lista.length) return null;
    if (lista.length === 1 || c.preco == null) return lista[0];
    return [...lista].sort((x, y) => Math.abs(x.p - c.preco) - Math.abs(y.p - c.preco))[0];
  }

  // ---- etiqueta -------------------------------------------------------------------------------------------------
  // a faixa e os textos ficam em cartao.js (3 linhas claras no card, detalhe ao passar o mouse)
  const etiqueta = (card, a) => globalThis.RadarCartao.desenhar(card, a);

  // ---- ciclo (as janelas flutuantes ficam em janelas.js) ---------------------------------------------------------
  function passar() {
    if (document.hidden) return;
    const cards = [];
    if (ligado) {
      const doJogo = document.querySelectorAll('.cm-card');
      if (doJogo.length) {
        // o card traz o número do anúncio no botão de favoritar
        for (const card of doJogo) {
          const fav = card.querySelector('[data-fav]');
          const id = fav ? Number(fav.getAttribute('data-fav')) : NaN;
          if (!Number.isInteger(id) || !card.querySelector('.cm-ficha')) continue; // card de item não tem ficha
          etiqueta(card, porId.get(id) || null);
          cards.push(card);
        }
      } else {
        // reserva: o jogo mudou a tela e o número do anúncio sumiu
        for (const b of botoesVerFicha()) {
          const card = cardDe(b);
          const c = lerCard(card);
          if (c.nivel == null || c.iv == null || c.nota == null) continue;
          etiqueta(card, acharAnuncio(c));
          cards.push(card);
        }
      }
    }
    for (const s of document.querySelectorAll('.rdm-etiqueta')) if (!cards.some((c) => c.contains(s))) s.remove();
    if (!cards.length) globalThis.RadarCartao.esconderDica();
  }
  // a tela mudou (página nova do Mercado, filtro, ficha fechada): a etiqueta entra em seguida, sem esperar o intervalo
  let agendado = null;
  function agendar() {
    if (agendado) return;
    agendado = setTimeout(() => {
      agendado = null;
      try { passar(); } catch (e) { console.error('[radar-mercado]', e); }
    }, 120);
  }
  new MutationObserver((muts) => {
    // as mudanças que a própria etiqueta faz não contam
    if (muts.some((m) => !(m.target instanceof Element && m.target.closest('.rdm-etiqueta, [id^="rdm-"]')))) agendar();
  }).observe(document.body, { childList: true, subtree: true });
  setInterval(passar, PASSO_MS);
})();
