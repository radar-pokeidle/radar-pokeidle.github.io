// Radar de Mercado (extensão dos jogadores) — gancho na conexão do jogo. Roda dentro da página (mundo MAIN), antes
// de a conexão abrir. Desde a 2.0 a extensão avalia no navegador da pessoa, então o gancho faz três coisas:
//  1. LÊ, do que o jogo recebe, só o Mercado: páginas de anúncios (vitrine), vendas (Tabela de preços), resumo de
//     itens e o catálogo de itens da entrada. Repassa ao resto da extensão sem nick de ninguém.
//  2. PEDE ao jogo, quando o resto da extensão manda e dentro de um ritmo: a 1ª página de anúncios recentes, as vendas
//     de uma espécie e o resumo de itens. As respostas dos pedidos da extensão não vão para a tela do jogo.
//  3. COMPRA AUTOMÁTICA (desligada de fábrica): envia UM pedido de compra quando a extensão manda e repassa o
//     resultado. Formato igual ao do jogo: { t: 'market.comprar', id, qtd: 1, preco, moeda, sorteioUi: 1 }.
// Não muda nada do jogo além disso e não manda nada para fora do navegador.
(function () {
  'use strict';
  const MARCA = Symbol.for('radar-mercado.gancho');
  if (window[MARCA]) return;
  window[MARCA] = true;

  const HOST = 'pokeidle.io';
  const MOEDAS = ['orb', 'gold'];
  // Ritmo dos pedidos da extensão. O jogo corta perto de 60 mensagens por minuto na conexão inteira ("Devagar aí").
  const INTERVALO_MS = 1500; // pausa mínima entre dois pedidos da extensão
  const TETO_POR_MINUTO = 20; // pedidos da extensão em qualquer janela de 60 s
  const ORCAMENTO_CONEXAO = 45; // com a conexão inteira acima disso no último minuto, a extensão cede a vez
  const FREIO_MS = 3 * 60_000; // o jogo pediu calma: nada de pedido por 3 min
  const ESPERA_MS = 8000; // quanto esperar a resposta de um pedido da extensão
  const JOGO_LISTOU_MS = 3000; // a tela acabou de pedir uma página: não pede "recentes" por cima

  const Nativo = window.WebSocket;
  const enviarNativo = Nativo.prototype.send;
  let conexao = null;
  let tardia = false; // a conexão já existia quando o gancho a achou: o jogo ouve as mensagens antes da extensão
  let pendente = null; // id do anúncio em compra: só as respostas dele interessam
  let pendenteEm = 0;
  const COMPRA_VALE_MS = 30_000; // compra sem desfecho depois disso deixa de segurar os pedidos da extensão
  const EH_FREIO = /devagar|muitas mensagens|slow down|rate.?limit|too many/i;

  const nossos = []; // horários dos pedidos da extensão
  const todos = []; // horários de tudo o que saiu pela conexão (do jogo e da extensão)
  let ultimoNosso = 0;
  let freadoAte = 0;
  let jogoListouEm = 0;
  let enviandoNosso = false;
  let esperaVitrine = null; // { em, moeda }
  let esperaItens = 0;
  let esperaItem = null; // { em, itemId, moeda }
  let relogioEm = 0; // última vez que a hora do servidor foi passada ao local.js
  const esperaVendas = new Map(); // seq -> horário do pedido
  let seq = 7_000_000 + Math.floor(Math.random() * 1_000_000);

  const emitir = (nome, dados) => document.dispatchEvent(new CustomEvent(nome, { detail: JSON.stringify(dados) }));
  const responder = (r) => emitir('rdm:resposta', r);

  function ehDoJogo(url) {
    try {
      const h = new URL(String(url), location.href).hostname;
      return h === HOST || h.endsWith('.' + HOST);
    } catch {
      return false;
    }
  }

  // ---- o que sai do gancho: só os campos que o motor usa (sem vendedor, comprador, apelido nem quem capturou) -----
  const pegar = (o, campos) => {
    const r = {};
    for (const c of campos) if (o[c] !== undefined) r[c] = o[c];
    return r;
  };
  const FICHA_ANUNCIO = ['id', 'nome', 'level', 'nota', 'potencia', 'quality', 'ivTotal', 'ivs', 'shiny', 'tmAoe', 'tmElemental', 'refinoTotal', 'speciesId'];
  const FICHA_VENDA = ['nome', 'level', 'nota', 'potencia', 'quality', 'ivTotal', 'shiny', 'tmAoe', 'tmElemental', 'speciesId'];
  const linhaAnuncio = (l) =>
    l && l.ficha && (!l.tipo || l.tipo === 'pokemon')
      ? { ...pegar(l, ['id', 'preco', 'moeda', 'criadoEm', 'compravelEm', 'estado', 'tipo']), ficha: pegar(l.ficha, FICHA_ANUNCIO) }
      : null;
  const linhaVenda = (l) =>
    l && l.ficha && l.tipo === 'pokemon' ? { ...pegar(l, ['id', 'tipo', 'moeda', 'bruto', 'valor', 'preco', 'qtd', 'em']), ficha: pegar(l.ficha, FICHA_VENDA) } : null;

  // ---- o Mercado que chega do jogo ---------------------------------------------------------------------------------
  function mercado(ev, t, cab) {
    if (cab.includes('"aba":"vitrine"')) {
      let j;
      try { j = JSON.parse(t); } catch { return; }
      const linhas = (Array.isArray(j.linhas) ? j.linhas : []).map(linhaAnuncio).filter(Boolean);
      const e = esperaVitrine;
      // É a resposta de um pedido da extensão se: há um pedido esperando, é a 1ª página de "recentes", sem critério
      // de filtro (o pedido da extensão não manda nenhum) e todos os anúncios são da moeda pedida. Uma página que a
      // própria pessoa pediu com filtro ou em outra moeda passa direto para a tela.
      const nossa = !!(
        e && Date.now() - e.em < ESPERA_MS && j.ordem === 'recentes' && j.pagina === 0 &&
        (!Array.isArray(j.criterios) || j.criterios.length === 0) && linhas.every((l) => l.moeda === e.moeda)
      );
      if (nossa) {
        esperaVitrine = null;
        ev.stopImmediatePropagation(); // resposta de um pedido da extensão: a tela do Mercado da pessoa não muda
      }
      emitir('rdm:vitrine', { nossa, moeda: nossa ? e.moeda : null, pagina: j.pagina, ordem: j.ordem, total: j.total, linhas });
    } else if (cab.includes('"aba":"historicoGlobal"')) {
      let j;
      try { j = JSON.parse(t); } catch { return; }
      const nossa = j.seq != null && esperaVendas.has(j.seq);
      if (nossa) {
        esperaVendas.delete(j.seq);
        ev.stopImmediatePropagation();
      }
      const linhas = (Array.isArray(j.linhas) ? j.linhas : []).map(linhaVenda).filter(Boolean);
      // a Tabela de preços que a própria pessoa abre também serve: são vendas a mais, de graça
      emitir('rdm:vendas', { seq: nossa ? j.seq : null, pagina: j.pagina, temMais: j.temMais === true, falhou: !Array.isArray(j.linhas), linhas });
    } else if (cab.includes('"aba":"itens"')) {
      let j;
      try { j = JSON.parse(t); } catch { return; }
      // a tela do jogo também pede o resumo, mas FILTRADO (por categoria e elemento): só a resposta do pedido da
      // extensão, que não leva filtro, é o resumo inteiro
      const nossa = !!(esperaItens && Date.now() - esperaItens < ESPERA_MS);
      if (nossa) {
        esperaItens = 0;
        ev.stopImmediatePropagation();
      }
      emitir('rdm:itens', { nossa, resumo: j.resumo || {}, medias: j.medias || {} });
    } else if (cab.includes('"aba":"item"')) {
      // os anúncios de UM item, do mais barato para o mais caro (para a compra automática de itens)
      let j;
      try { j = JSON.parse(t); } catch { return; }
      const e = esperaItem;
      // a resposta pode vir sem a moeda: aí vale a do nosso pedido (o mesmo item, há pouco)
      // e sem o id do item: vale o do nosso pedido, se ele acabou de sair
      const recente = !!(e && Date.now() - e.em < ESPERA_MS);
      const itemId = j.itemId != null ? Number(j.itemId) : recente ? e.itemId : NaN;
      const doPedido = recente && itemId === e.itemId;
      const moeda = j.moeda === 'orb' || j.moeda === 'gold' ? j.moeda : doPedido ? e.moeda : null;
      const nossa = doPedido && moeda === e.moeda;
      if (nossa) {
        esperaItem = null;
        ev.stopImmediatePropagation();
      }
      const linhas = (Array.isArray(j.linhas) ? j.linhas : [])
        // as linhas da tela de item não trazem 'tipo' (só id, preço, qtd, estado e horas): aceita sem ele
        .filter((l) => l && (l.tipo == null || l.tipo === 'item'))
        .map((l) => pegar(l, ['id', 'preco', 'qtd', 'estado', 'compravelEm', 'criadoEm']));
      if (!moeda || !Number.isInteger(itemId)) return; // sem saber o item e a moeda, não serve para comprar
      emitir('rdm:item', { nossa, itemId, moeda, linhas });
    }
  }

  // o catálogo de itens vem na entrada do jogo (welcome): só id, nome e categoria saem daqui
  function entrada(t) {
    let m;
    try { m = JSON.parse(t); } catch { return; }
    const cat = ((m && m.mercado) || (m && m.dados && m.dados.mercado) || {}).catalogo;
    if (!Array.isArray(cat) || !cat.length) return;
    emitir('rdm:catalogo', cat.filter((c) => c && c.id != null && c.nome).map((c) => ({ id: c.id, nome: String(c.nome), categoria: c.categoria == null ? null : String(c.categoria) })));
  }

  function compra(t, cab) {
    if (pendente == null) return;
    if (cab.includes('"t":"erro"')) {
      // "devagar aí" não é recusa da compra (pode ser de outro pedido): a compra sai da vez sem contar como recusa
      if (EH_FREIO.test(t)) {
        responder({ tipo: 'freio', id: pendente });
        pendente = null;
        return;
      }
      const tipo = /retencao|retido/i.test(t) ? 'retido' : /sorteio/i.test(t) ? 'sorteio' : 'erro';
      let msg = '';
      try { const m = JSON.parse(t); msg = String(m.msg || m.chave || '').slice(0, 80); } catch { /* fica vazio */ }
      responder({ tipo, id: pendente, msg });
      if (tipo === 'erro') pendente = null;
      return;
    }
    if (cab.includes('"t":"batalha"') && (t.includes('"mktSorteio"') || t.includes('"marketComprado"'))) {
      let m;
      try { m = JSON.parse(t); } catch { return; }
      for (const e of [].concat(m.ev || [])) {
        if (!e) continue;
        if (e.k === 'marketComprado') {
          // se o aviso trouxer o id e for de outro anúncio (compra feita à mão ao mesmo tempo), não é a nossa
          const idAviso = Number(e.id != null ? e.id : e.anuncioId);
          if (Number.isFinite(idAviso) && idAviso > 0 && idAviso !== pendente) continue;
          responder({ tipo: 'fim', id: pendente, ok: true });
          pendente = null;
          return;
        }
        if (e.k === 'mktSorteio' && Number(e.id) === pendente) {
          if (e.fase === 'entrou') responder({ tipo: 'sorteio', id: pendente });
          if (e.fase === 'fim') { responder({ tipo: 'fim', id: pendente, ok: e.ok === true, perdeu: !!e.perdeu, msg: String(e.msg || '').slice(0, 80) }); pendente = null; }
        }
      }
    }
  }

  // A hora do servidor (vem no "estado" do jogo): a compra de item retido é marcada para o segundo em que o anúncio
  // libera, e o relógio do PC pode estar alguns segundos fora. Passa a diferença ao local.js uma vez por minuto.
  function relogio(t) {
    const agora = Date.now();
    if (agora - relogioEm < 60_000) return;
    const m = /"servidorAgora":(\d{12,14})/.exec(t);
    if (!m) return;
    relogioEm = agora;
    emitir('rdm:relogio', { diferenca: Number(m[1]) - agora });
  }

  function aoReceber(ev) {
    if (typeof ev.data !== 'string') return;
    const t = ev.data;
    const cab = t.slice(0, 60);
    try {
      if (cab.includes('"t":"erro"') && EH_FREIO.test(t)) {
        freadoAte = Date.now() + FREIO_MS;
        // o pedido que estava esperando não vai ter resposta: sem isto, a próxima página que a própria pessoa
        // abrisse nos 8 s seguintes seria tomada como resposta da extensão e não chegaria à tela
        esperaVitrine = null;
        esperaItens = 0;
        esperaItem = null;
        esperaVendas.clear();
        emitir('rdm:freio', { ate: freadoAte });
      }
      if (cab.includes('"t":"market"')) mercado(ev, t, cab);
      else if (cab.includes('"t":"welcome"')) entrada(t);
      else if (cab.includes('"t":"estado"')) relogio(t);
      compra(t, cab);
    } catch (e) {
      console.error('[radar-mercado]', e);
    }
  }

  function ouvir(ws, jaAberta) {
    if (ws.__rdm) return;
    try { Object.defineProperty(ws, '__rdm', { value: true }); } catch { /* segue sem a marca */ }
    conexao = ws;
    tardia = !!jaAberta;
    ws.addEventListener('message', aoReceber);
    ws.addEventListener('open', () => {
      conexao = ws;
      emitir('rdm:conexao', { aberta: true, tardia });
    });
    ws.addEventListener('close', () => {
      if (conexao !== ws) return;
      conexao = null;
      esperaVitrine = null;
      esperaItens = 0;
      esperaVendas.clear();
      emitir('rdm:conexao', { aberta: false });
    });
    if (ws.readyState === 1) emitir('rdm:conexao', { aberta: true, tardia });
  }

  function Envolto(...args) {
    const ws = new Nativo(...args);
    try { if (ehDoJogo(args[0])) ouvir(ws, false); } catch (e) { console.error('[radar-mercado]', e); }
    return ws;
  }
  Envolto.prototype = Nativo.prototype;
  for (const k of ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED']) Envolto[k] = Nativo[k];
  window.WebSocket = Envolto;

  // Conta o que sai pela conexão (para o orçamento) e nota quando a tela do jogo pede uma página do Mercado.
  // Se a extensão foi recarregada com o jogo aberto, é aqui que ela acha a conexão que já existia.
  Nativo.prototype.send = function (dados) {
    try {
      if (this === conexao || ehDoJogo(this.url)) {
        todos.push(Date.now());
        if (todos.length > 400) todos.splice(0, 200);
        if (!enviandoNosso && typeof dados === 'string' && dados.indexOf('"market.listar"') !== -1) jogoListouEm = Date.now();
        if (this !== conexao && this.readyState === 1 && (!conexao || conexao.readyState !== 1)) ouvir(this, true);
      }
    } catch { /* nunca atrapalha o envio do jogo */ }
    return enviarNativo.apply(this, arguments);
  };

  function enviarNosso(obj) {
    enviandoNosso = true;
    try { enviarNativo.call(conexao, JSON.stringify(obj)); } finally { enviandoNosso = false; }
    const agora = Date.now();
    ultimoNosso = agora;
    nossos.push(agora);
    todos.push(agora);
  }
  const noUltimoMinuto = (lista) => {
    const limite = Date.now() - 60_000;
    while (lista.length && lista[0] < limite) lista.shift();
    return lista.length;
  };
  const mercadoNaTela = () => {
    const el = document.getElementById('cm-lista');
    return !!(el && el.offsetParent !== null);
  };
  const inteiro = (v, a, b) => Number.isInteger(v) && v >= a && v <= b;

  // ---- pedidos da extensão ao jogo: { ref, tipo: 'recentes' | 'vendas' | 'itens', ... } ---------------------------
  // Resposta em 'rdm:pedido': { ref, ok, motivo?, seq? }. Recusado = quem pediu tenta de novo mais tarde.
  document.addEventListener('rdm:pedir', (ev) => {
    let p;
    try { p = JSON.parse(ev.detail); } catch { return; }
    if (!p || typeof p.ref !== 'number') return;
    const recusar = (motivo) => emitir('rdm:pedido', { ref: p.ref, ok: false, motivo });
    const agora = Date.now();
    if (!conexao || conexao.readyState !== 1) return recusar('sem-conexao');
    if (agora < freadoAte) return recusar('freio');
    if (pendente != null && agora - pendenteEm > COMPRA_VALE_MS) pendente = null; // compra que ficou sem desfecho
    if (pendente != null) return recusar('comprando'); // a compra tem a vez
    if (agora - ultimoNosso < INTERVALO_MS) return recusar('cedo');
    if (noUltimoMinuto(nossos) >= TETO_POR_MINUTO) return recusar('teto');
    if (noUltimoMinuto(todos) >= ORCAMENTO_CONEXAO) return recusar('ocupada');
    for (const [s, em] of esperaVendas) if (agora - em > 4 * ESPERA_MS) esperaVendas.delete(s);

    if (p.tipo === 'recentes') {
      if (!MOEDAS.includes(p.moeda)) return recusar('invalido');
      if (esperaVitrine && agora - esperaVitrine.em < ESPERA_MS) return recusar('esperando');
      if (agora - jogoListouEm < JOGO_LISTOU_MS) return recusar('jogo-listando');
      if (tardia && mercadoNaTela()) return recusar('mercado-aberto'); // sem poder segurar a resposta, não repinta a tela
      esperaVitrine = { em: agora, moeda: p.moeda };
      // os mesmos campos que a tela do jogo manda ao abrir a vitrine de pokémon, sem filtro nenhum
      enviarNosso({
        t: 'market.listar', tipo: 'pokemon', moeda: p.moeda, busca: '', ordem: 'recentes', criterios: [], elementos: [], categoria: '',
        soShiny: false, soP5: false, soMega: false, soLendario: false, soTmElemental: false, soTmAoe: false, semOutland: false,
        nivelMin: '', nivelMax: '', notaMin: '', notaMax: '', ivMin: '', ivMax: '', potenciaMin: '', potenciaMax: '',
        qualidadeMin: '', qualidadeMax: '', pagina: 0, especieId: 0,
      });
      return emitir('rdm:pedido', { ref: p.ref, ok: true });
    }
    if (p.tipo === 'vendas') {
      const busca = typeof p.busca === 'string' ? p.busca.trim().slice(0, 40) : '';
      if (!busca || !MOEDAS.includes(p.moeda) || !inteiro(p.pagina, 0, 40)) return recusar('invalido');
      const s = ++seq;
      esperaVendas.set(s, agora);
      const corpo = { t: 'market.historicoGlobal', seq: s, pagina: p.pagina, tipo: 'pokemon', moeda: p.moeda, busca };
      if (p.soShiny) corpo.soShiny = 1;
      if (p.soP5) corpo.soP5 = 1;
      enviarNosso(corpo);
      return emitir('rdm:pedido', { ref: p.ref, ok: true, seq: s });
    }
    if (p.tipo === 'itens') {
      if (esperaItens && agora - esperaItens < ESPERA_MS) return recusar('esperando');
      esperaItens = agora;
      enviarNosso({ t: 'market.itens' });
      return emitir('rdm:pedido', { ref: p.ref, ok: true });
    }
    if (p.tipo === 'item') {
      if (!inteiro(p.itemId, 1, 1e9) || !MOEDAS.includes(p.moeda)) return recusar('invalido');
      if (esperaItem && agora - esperaItem.em < ESPERA_MS) return recusar('esperando');
      esperaItem = { em: agora, itemId: p.itemId, moeda: p.moeda };
      enviarNosso({ t: 'market.item', itemId: p.itemId, moeda: p.moeda });
      return emitir('rdm:pedido', { ref: p.ref, ok: true });
    }
    return recusar('invalido');
  });

  // A extensão pede a compra por um evento; só passa o que é uma compra de UM anúncio, com preço e moeda válidos.
  document.addEventListener('rdm:comprar', (ev) => {
    let p;
    try { p = JSON.parse(ev.detail); } catch { return; }
    // qtd: só a compra de item manda mais de 1 (várias unidades do mesmo anúncio); preco é sempre por unidade
    const qtd = p && p.qtd != null ? p.qtd : 1;
    if (!p || !inteiro(p.id, 1, Number.MAX_SAFE_INTEGER) || !MOEDAS.includes(p.moeda) || !inteiro(p.preco, 1, p.moeda === 'orb' ? 1e7 : 1e13) || !inteiro(qtd, 1, 100000)) {
      responder({ tipo: 'erro', id: p && p.id, msg: 'pedido inválido' });
      return;
    }
    if (!conexao || conexao.readyState !== 1) { responder({ tipo: 'sem-conexao', id: p.id }); return; }
    pendente = p.id;
    pendenteEm = Date.now();
    enviarNativo.call(conexao, JSON.stringify({ t: 'market.comprar', id: p.id, qtd, preco: p.preco, moeda: p.moeda, sorteioUi: 1 }));
    todos.push(Date.now());
  });
})();
