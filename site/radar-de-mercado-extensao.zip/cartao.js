// Radar de Mercado (extensão dos jogadores) — a faixa de cada card do Mercado e os textos que a extensão mostra.
// A faixa entra dentro do card, no rodapé, logo acima do preço (o card cresce um pouco), com 3 linhas em português
// claro: o veredito e quanto está abaixo ou acima, quanto vale, e em quantas vendas a conta se apoia. O detalhe (faixa
// de preço, reais, potencial, IV útil…) abre numa caixinha ao passar o mouse.
(function () {
  'use strict';
  if (globalThis.RadarCartao) return;

  // 0,0100 USDT por gema (o que o jogo cobra na compra de gemas) × R$ 5,80, cotação fixa (decisão de 24/11/2026)
  const REAIS_POR_GEMA = 0.058;
  const NOME = { excepcional: '★ EXCEPCIONAL', otimo: 'ÓTIMO', bom: 'BOM', justo: 'JUSTO', caro: 'CARO', '?': 'SEM PREÇO DE MERCADO' };
  const COR = { excepcional: '#b8860b', otimo: '#14833b', bom: '#2f9b5a', justo: '#6b6475', caro: '#a8323e', '?': '#4b4555' };

  const n0 = (v) => (v == null ? '—' : Math.round(v).toLocaleString('pt-BR'));
  const umaCasa = (v) => v.toLocaleString('pt-BR', { maximumFractionDigits: 1 });
  /** número curto para caber no card: 4.050 · 83,5 mil · 1,2 mi · 2,7 bi */
  const curto = (v) => (v == null ? '—' : v >= 1e9 ? `${umaCasa(v / 1e9)} bi` : v >= 1e6 ? `${umaCasa(v / 1e6)} mi` : v >= 1e5 ? `${umaCasa(v / 1e3)} mil` : n0(v));
  const moedaDe = (m) => (m === 'c' || m === 'gold' ? 'coins' : 'gemas');
  const emGemas = (m) => m === 'g' || m === 'orb';
  const reais = (gemas) => {
    const v = gemas * REAIS_POR_GEMA;
    return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: v >= 100 ? 0 : 2 });
  };
  const vendas = (n) => `${n} venda${n === 1 ? '' : 's'} parecida${n === 1 ? '' : 's'}`;
  /** "38% abaixo do mercado" · "83% acima do mercado" · "no preço do mercado" */
  // muito acima (3× ou mais) vira "6,7× o valor": "573% acima" e "43.922% acima" não dizem nada a quem lê
  const contraMercado = (vs, curtinho) =>
    vs == null
      ? ''
      : vs === 0
        ? 'no preço' + (curtinho ? '' : ' do mercado')
        : vs >= 900
          ? curtinho ? 'muito acima' : 'mais de 10× acima do valor de mercado'
          : vs >= 200
          ? `${umaCasa(1 + vs / 100)}× o valor${curtinho ? '' : ' de mercado'}`
          : `${Math.abs(vs)}% ${vs < 0 ? 'abaixo' : 'acima'}${curtinho ? '' : ' do mercado'}`;

  // Para o motor, JUSTO é "dentro da faixa onde ficou a maioria das vendas parecidas". Quando essas vendas variam
  // muito de preço, o anúncio pode estar bem longe do meio da faixa e ainda ser JUSTO: "JUSTO · 146% acima" confunde,
  // então nesse caso o card mostra a faixa no lugar da porcentagem.
  const faixaLarga = (a) => a.v === 'justo' && a.vs != null && Math.abs(a.vs) > 20 && a.q1 > 0 && a.q3 > a.q1;

  // ---- as 3 linhas do card -----------------------------------------------------------------------------------------
  function linhas(a) {
    if (!a) return ['Radar: avaliando…'];
    if (a.v === '?') return a.bu ? ['Radar: buscando vendas…'] : [NOME['?'], 'menos de 3 vendas parecidas'];
    if (faixaLarga(a)) return ['JUSTO · na faixa', `vendas de ${curto(a.q1)} a ${curto(a.q3)}`, a.n ? vendas(a.n) + (a.la ? ' (aprox.)' : '') : ''].filter(Boolean);
    const boa = a.v === 'bom' || a.v === 'otimo' || a.v === 'excepcional';
    return [
      [NOME[a.v] || String(a.v).toUpperCase(), contraMercado(a.vs, true)].filter(Boolean).join(' · '),
      a.med ? `vale ~${curto(a.med)} ${moedaDe(a.m)}` : '',
      // na boa compra, o que interessa é quanto sobra revendendo; nas outras, em quantas vendas a conta se apoia
      boa && a.lu ? `lucro ~${curto(a.lu)} · ${a.n} venda${a.n === 1 ? '' : 's'}` : a.n ? vendas(a.n) + (a.la ? ' (aprox.)' : '') : '',
      emGemas(a.m) ? `preço ≈ ${reais(a.p)}` : '',
    ].filter(Boolean);
  }
  /** conta apoiada em pouca coisa (menos de 5 vendas, ou referência aproximada): a faixa ganha borda tracejada */
  const incerto = (a) => !!a && a.v !== '?' && ((a.n || 0) < 5 || !!a.la || !!a.g2);

  // ---- o detalhe, para quem passa o mouse --------------------------------------------------------------------------
  function detalhe(a) {
    if (!a) return ['O Radar busca as vendas desta espécie na Tabela de preços do jogo e avalia aqui, no seu navegador. Leva alguns segundos.'];
    const g = emGemas(a.m);
    const dinheiro = (v) => `${n0(v)} ${moedaDe(a.m)}${g ? ` (≈ ${reais(v)})` : ''}`;
    const t = [];
    t.push(`Preço pedido: ${dinheiro(a.p)}`);
    if (a.med) {
      t.push(`Valor de mercado: ~${dinheiro(a.med)}`);
      if (a.q1 && a.q3 && a.q3 > a.q1) t.push(`A maioria das vendas parecidas ficou entre ${n0(a.q1)} e ${n0(a.q3)}.`);
      if (faixaLarga(a)) t.push('As vendas parecidas variam muito de preço. Este anúncio está dentro da faixa delas.');
      else t.push(a.vs != null ? `Este anúncio está ${contraMercado(a.vs, false)}.` : '');
      // Visto nas vendas do jogo em 24/11/2026: espécie comum que sai por ~6 gemas tem, de vez em quando, uma venda
      // de centenas ou milhares, sem nada no Pokémon que explique. O valor de mercado continua sendo o das vendas comuns.
      if (a.vs >= 900) t.push('Pokémon parecidos com este saem por muito menos. Um preço tão acima das vendas pode ser uma transferência entre contas, e não uma oferta para o mercado.');
      if (a.g2) t.push(`Atenção: as vendas parecidas se dividem em dois grupos de preço, perto de ${n0(a.g2[0])} e perto de ${n0(a.g2[1])}. O valor de mercado fica entre os dois e pode enganar.`);
      if (a.lu) t.push(`Revendendo pelo preço de mercado sobram ~${dinheiro(a.lu)}, já sem a taxa do Mercado.`);
      if (incerto(a) && !a.g2) t.push('Borda tracejada: poucas vendas parecidas. Use como referência, não como certeza.');
      t.push(`Conta feita com ${vendas(a.n || 0)}${a.la ? ', de potência ou Nota vizinha (referência aproximada: o veredito não passa de BOM)' : ''}.`);
    } else if (a.bu) t.push('Ainda buscando as vendas desta espécie na Tabela de preços do jogo.');
    else t.push('Menos de 3 vendas parecidas nos últimos 45 dias: sem base para dizer quanto vale.');
    const forca = [a.i > 0 ? `Oportunidade ${a.i}/100` : '', a.rar != null ? `entre os ${a.rar}% melhores da espécie` : ''].filter(Boolean).join(' · ');
    if (forca) t.push(forca);
    const corpo = [a.pot ? `Potencial ${n0(a.pot)}` : '', a.iu != null ? `IV útil ${a.iu}%` : '', a.rf ? `+${a.rf} de refino` : '', a.f != null ? `⚔ ${n0(a.f)} no Nv 100` : ''].filter(Boolean).join(' · ');
    if (corpo) t.push(corpo);
    if (a.d != null && a.d >= 1) t.push(`Está à venda há ${a.d} dia${a.d === 1 ? '' : 's'}.`);
    t.push('Estimativa pelas vendas reais do jogo, calculada no seu navegador. Não é garantia de lucro.');
    return t.filter(Boolean);
  }

  // ---- a caixinha do detalhe (uma só, flutuante) -----------------------------------------------------------------
  let dica = null;
  function mostrarDica(alvo, textos) {
    if (!dica) {
      dica = document.createElement('div');
      dica.id = 'rdm-dica';
      dica.style.cssText =
        'position:fixed;z-index:2147483600;max-width:280px;padding:8px 10px;border-radius:10px;border:1px solid #57323f;background:#1c1015f7;color:#f6ece6;font:500 12px/1.45 system-ui,sans-serif;box-shadow:0 10px 30px #000c;pointer-events:none;display:none';
      document.body.appendChild(dica);
    }
    dica.textContent = '';
    textos.forEach((txt, i) => {
      const d = document.createElement('div');
      d.textContent = txt;
      if (i === textos.length - 1 && textos.length > 1) d.style.cssText = 'margin-top:6px;color:#93767c;font-size:11px';
      else if (i > 0) d.style.marginTop = '3px';
      dica.appendChild(d);
    });
    dica.style.display = 'block';
    const r = alvo.getBoundingClientRect();
    const larg = dica.offsetWidth;
    const alt = dica.offsetHeight;
    const x = Math.max(8, Math.min(r.left, innerWidth - larg - 8));
    const abaixo = r.bottom + 6 + alt <= innerHeight - 8;
    dica.style.left = `${x}px`;
    dica.style.top = `${abaixo ? r.bottom + 6 : Math.max(8, r.top - alt - 6)}px`;
  }
  function esconderDica() {
    if (dica) dica.style.display = 'none';
  }

  // ---- a faixa no card ---------------------------------------------------------------------------------------------
  const ESTILO_BASE = 'border-radius:6px;padding:4px 6px;font:500 10px/1.3 system-ui,sans-serif;color:#fff;cursor:help;text-align:left;';
  function criar(card) {
    const s = document.createElement('div');
    s.className = 'rdm-etiqueta';
    const rodape = card.querySelector('.cm-rodape');
    if (rodape) {
      // dentro do card, entre o "Ver ficha" e o preço
      s.style.cssText = ESTILO_BASE + 'display:block;margin:0 0 4px;';
      rodape.insertBefore(s, rodape.firstChild);
    } else {
      // reserva: o jogo mudou o card e o rodapé sumiu; a faixa vai por cima do desenho
      if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
      s.style.cssText = ESTILO_BASE + 'position:absolute;left:6px;right:6px;top:30px;z-index:5;box-shadow:0 2px 6px #0008;';
      card.appendChild(s);
    }
    s.addEventListener('mouseenter', () => mostrarDica(s, detalhe(s.__rdm || null)));
    s.addEventListener('mouseleave', esconderDica);
    return s;
  }

  function desenhar(card, a) {
    const s = card.querySelector('.rdm-etiqueta') || criar(card);
    const assinatura = a ? [a.id, a.v, a.vs, a.med, a.n, a.p, a.bu || 0, a.la || 0, a.lu || 0, a.g2 ? 1 : 0].join('|') : '-';
    s.__rdm = a || null;
    if (s.dataset.rdm === assinatura) return; // nada mudou: não mexe na tela
    s.dataset.rdm = assinatura;
    s.textContent = '';
    s.style.background = (a && !(a.v === '?' && a.bu) ? COR[a.v] || COR['?'] : '#3a3445') + 'ee';
    s.style.outline = incerto(a) ? '1px dashed #ffffffaa' : 'none';
    s.style.outlineOffset = '-2px';
    linhas(a).forEach((txt, i) => {
      const d = document.createElement('div');
      d.textContent = txt;
      if (i === 0) d.style.cssText = 'font-weight:800;font-size:11px';
      s.appendChild(d);
    });
  }

  /** a porcentagem curtinha das listas: "-38%", "+82%", "6,7×", ">10×" */
  const pct = (vs) => (vs == null ? '' : vs >= 900 ? '>10×' : vs >= 200 ? `${umaCasa(1 + vs / 100)}×` : `${vs > 0 ? '+' : ''}${vs}%`);

  globalThis.RadarCartao = { pct, desenhar, esconderDica, mostrarDica, n0, curto, reais, moedaDe, emGemas, vendas, contraMercado, NOME, COR };
})();
