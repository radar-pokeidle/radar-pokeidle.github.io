// Radar de Mercado (extensão dos jogadores) — cérebro local (2.0). Roda na página do jogo, no mundo isolado da
// extensão, depois de motor.js. Desde a 2.0 a avaliação é feita aqui, no navegador da pessoa, sem o nosso banco:
//  - recebe do gancho os anúncios que passam pela conexão (as páginas que a pessoa folheia e a 1ª página de recentes
//    que a extensão pede a cada 30 s, alternando gemas e coins);
//  - para cada espécie que aparece, pede ao jogo as vendas dela (Tabela de preços) e guarda no navegador por 45 dias;
//  - avalia com o mesmo motor do site e grava o resultado em chrome.storage.local.anuncios, no formato compacto que
//    as etiquetas, o painel, os alertas e a compra automática já usam;
//  - lê o resumo de itens do jogo para os custos do motor (pedras, movimentos, câmbio) e o alerta de preço de item.
// Nada daqui sai do navegador: as vendas ficam no IndexedDB desta página, sem nick de ninguém.
(function () {
  'use strict';
  const M = globalThis.RadarMotor;
  if (!M || globalThis.__rdmLocal) return;
  globalThis.__rdmLocal = true;

  const MIN = 60_000;
  const DIA = 864e5;
  const JANELA_VENDAS_MS = 45 * DIA; // a referência larga do motor olha até 45 dias
  const VENDAS_VALE_MS = 30 * MIN; // a mesma espécie não é buscada de novo antes disso
  const VENDAS_FALHA_MS = 5 * MIN; // busca que falhou: espera antes de tentar outra vez
  const PAGINAS_PRIMEIRA = 3; // 1ª busca de uma espécie: até 90 vendas
  const PAGINAS_DEPOIS = 2; // depois: para na primeira venda que já conhece
  const RECENTES_CADA_MS = 30_000; // gemas e coins alternados: cada moeda a cada 1 min
  const ITENS_CADA_MS = 15 * MIN;
  const CUSTOS_VALEM_MS = 6 * 3600_000;
  const NOVO_MS = 10 * MIN; // anúncio criado há menos que isso conta como novo (alerta e compra)
  const ANUNCIO_VALE_MS = 6 * 3600_000; // anúncio que a extensão não vê há mais que isso sai da lista
  const MAX_ANUNCIOS = 2500;
  const PASSO_MS = 500;
  const ENTRE_PEDIDOS_MS = 1600;
  const SEM_RESPOSTA_MS = 9000;
  const AVALIAR_EM_MS = 700;
  // 10 unidades de cada item e o câmbio coins/gema, medidos no jogo em 24/11/2026. Valem até o resumo de itens chegar.
  const CUSTOS_PADRAO = { aoe: 4750, tmZ: 2090, pedraShiny: 920, megaShinyStone: 4530, megaStone: 1070, cambio: 5e6 };
  const ITEM_DO_CUSTO = { 40530: 'aoe', 59194: 'tmZ', 70012: 'pedraShiny', 70015: 'megaShinyStone', 70014: 'megaStone' };
  const ITEM_CADA_MS = 20_000; // compra automática de itens: cada item com regra é olhado nesse intervalo
  const ITEM_ESPACO_MS = 6000; // e nunca dois pedidos de item em menos que isso
  const soCoins = (categoria) => categoria === 'stone'; // pedra: o mercado é só em coins

  // ---- estado ------------------------------------------------------------------------------------------------------
  const vistos = new Map(); // id do anúncio -> { a, em, novo, avisado }
  const vendas = new Map(); // "nome|moeda" -> Map(id da venda -> venda)
  const buscas = new Map(); // "nome|moeda|classe" -> { em, falhaEm }
  const fila = []; // buscas de vendas à espera: { chave, nome, moeda, classe, pagina, limite, prio, conhecia }
  const paraAvaliar = new Set();
  let emCurso = null; // pedido à espera de resposta: { ref, tipo, tarefa?, seq?, em }
  let proximoEm = 0;
  let ref = 0;
  let conectado = false;
  let lider = false;
  let freadoAte = 0;
  let recentesEm = 0;
  let moedaDaVez = 'orb';
  let itensEm = 0;
  let itensForcar = true; // ao abrir o jogo, o resumo inteiro uma vez: a lista de itens do menu sai dele
  let custos = { ...CUSTOS_PADRAO };
  let custosEm = 0;
  let catalogo = null; // [{ id, nome, categoria }]
  let regras = {};
  let acompanhar = true;
  let diferencaServidor = 0; // hora do servidor menos a do PC (gancho.js)
  const comprasMarcadas = new Map(); // id do anúncio de item retido -> timer da compra marcada para quando ele libera
  let avaliarTimer = null;
  let gravando = Promise.resolve();
  let banco = null;
  // para o popup dizer o que está acontecendo: pedidos que o gancho aceitou e recusou, e o último motivo de recusa
  let aceitos = 0;
  let recusados = 0;
  let semResposta = 0;
  let ultimaRecusa = null;

  const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);
  const classeDe = (shiny, potencia) => (shiny ? 's' : Number(potencia) >= 5 ? '5' : '');
  const pedir = (dados) => document.dispatchEvent(new CustomEvent('rdm:pedir', { detail: JSON.stringify(dados) }));
  const ouvir = (nome, fn) =>
    document.addEventListener(nome, (ev) => {
      let d;
      try { d = JSON.parse(ev.detail); } catch { return; }
      try { fn(d); } catch (e) { console.error('[radar-mercado]', e); }
    });

  // ---- o que o jogo manda vira o que o motor espera (igual ao avaliador do site) ------------------------------
  function anuncioDe(l) {
    const f = l.ficha;
    if (!f || !f.nome || num(l.id) == null || num(l.preco) == null) return null;
    if ((l.moeda !== 'orb' && l.moeda !== 'gold') || (l.estado && l.estado !== 'aberto')) return null;
    const iv = f.ivs || {};
    return {
      id: l.id, moeda: l.moeda, nome: String(f.nome), nivel: num(f.level), nota: num(f.nota), potencia: num(f.potencia), qualidade: num(f.quality),
      ivTotal: num(f.ivTotal), hp: num(iv.hp), atk: num(iv.atk), def: num(iv.def), spAtk: num(iv.spAtk), spDef: num(iv.spDef), speed: num(iv.speed),
      refino: num(f.refinoTotal) ?? 0, shiny: Boolean(f.shiny), tmAoe: Boolean(f.tmAoe), tmZ: f.tmElemental ?? null, preco: l.preco,
      criadoEm: num(l.criadoEm), pokemonId: num(f.id), compravelEm: num(l.compravelEm), estado: l.estado ?? null,
    };
  }
  function vendaDe(l) {
    const f = l.ficha;
    if (!f || !f.nome || num(l.id) == null || num(l.em) == null || (l.moeda !== 'orb' && l.moeda !== 'gold')) return null;
    const bruto = num(l.bruto) ?? num(l.valor) ?? num(l.preco) ?? 0;
    const preco = Math.round(bruto / Math.max(1, num(l.qtd) ?? 1));
    if (preco <= 0) return null;
    const q = num(f.quality);
    return {
      id: String(l.id), em: l.em, nome: String(f.nome), moeda: l.moeda, preco, nivel: num(f.level) ?? 1, shiny: Boolean(f.shiny), pot: num(f.potencia) ?? 1,
      q: q != null && q > 10 ? q / 1000 : q, iv: num(f.ivTotal), nota: num(f.nota), tmAoe: Boolean(f.tmAoe), tmZ: f.tmElemental ?? null,
    };
  }

  // ---- vendas guardadas no navegador (IndexedDB desta página) -----------------------------------------------------
  function abrirBanco() {
    return new Promise((ok) => {
      try {
        const r = indexedDB.open('radar-mercado', 1);
        r.onupgradeneeded = () => {
          r.result.createObjectStore('vendas');
          r.result.createObjectStore('buscas');
        };
        r.onsuccess = () => ok(r.result);
        r.onerror = () => ok(null);
      } catch {
        ok(null); // sem IndexedDB (janela anônima, por exemplo): segue só com a memória
      }
    });
  }
  function lerTudo(nome) {
    return new Promise((ok) => {
      if (!banco) return ok([]);
      const saida = [];
      const cur = banco.transaction(nome).objectStore(nome).openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return ok(saida);
        saida.push([c.key, c.value]);
        c.continue();
      };
      cur.onerror = () => ok(saida);
    });
  }
  function guardar(nome, chave, valor) {
    if (!banco) return;
    try {
      const tx = banco.transaction(nome, 'readwrite');
      tx.onerror = tx.onabort = () => {}; // sem espaço ou banco fechado: a venda fica só na memória desta página
      tx.objectStore(nome).put(valor, chave);
    } catch { /* fica só na memória */ }
  }
  /** numa aba aberta por dias, tira da memória e do banco as vendas que saíram da janela de 45 dias */
  function podarVendas() {
    const limite = Date.now() - JANELA_VENDAS_MS;
    for (const [chave, m] of vendas) {
      let mudou = false;
      for (const [id, v] of m) {
        if (v.em < limite) {
          m.delete(id);
          mudou = true;
        }
      }
      if (!mudou) continue;
      if (m.size) guardar('vendas', chave, [...m.values()]);
      else {
        vendas.delete(chave);
        guardar('vendas', chave, []);
      }
    }
  }
  async function carregar() {
    banco = await abrirBanco();
    const limite = Date.now() - JANELA_VENDAS_MS;
    for (const [chave, lista] of await lerTudo('vendas')) {
      const recentes = (Array.isArray(lista) ? lista : []).filter((v) => v && v.em >= limite);
      if (recentes.length) vendas.set(chave, new Map(recentes.map((v) => [v.id, v])));
      if (recentes.length !== (lista || []).length) guardar('vendas', chave, recentes);
    }
    for (const [chave, b] of await lerTudo('buscas')) if (b && b.em) buscas.set(chave, { em: b.em, falhaEm: 0 });
  }

  // ---- fila das buscas de vendas -----------------------------------------------------------------------------------
  const chaveBusca = (a) => `${a.nome}|${a.moeda}|${classeDe(a.shiny, a.potencia)}`;
  /** ainda falta a 1ª página de vendas desta espécie (as páginas de refino não contam como pendência) */
  function buscaPendente(a) {
    const k = chaveBusca(a);
    return fila.some((t) => t.chave === k && !t.resto) || !!(emCurso && emCurso.tarefa && emCurso.tarefa.chave === k && !emCurso.tarefa.resto);
  }
  /** põe a busca das vendas da espécie na fila, se ainda não está em dia; prio menor = antes */
  function garantirVendas(a, prio) {
    const k = chaveBusca(a);
    const b = buscas.get(k);
    const agora = Date.now();
    if (b && (agora - b.em < VENDAS_VALE_MS || (b.falhaEm && agora - b.falhaEm < VENDAS_FALHA_MS))) return;
    const naFila = fila.find((t) => t.chave === k);
    if (naFila) {
      // sobrou uma página de refino de uma busca antiga: a espécie precisa da 1ª página de novo (as vendas recentes)
      if (naFila.resto) Object.assign(naFila, { pagina: 0, resto: false, limite: PAGINAS_DEPOIS, prio });
      else naFila.prio = Math.min(naFila.prio, prio);
      return;
    }
    if (emCurso && emCurso.tarefa && emCurso.tarefa.chave === k) return;
    fila.push({ chave: k, nome: a.nome, moeda: a.moeda, classe: classeDe(a.shiny, a.potencia), pagina: 0, limite: b && b.em ? PAGINAS_DEPOIS : PAGINAS_PRIMEIRA, prio, conhecia: false });
  }
  function marcarEspecie(nome, moeda) {
    for (const [id, v] of vistos) if (v.a.nome === nome && v.a.moeda === moeda) paraAvaliar.add(id);
    agendarAvaliacao();
  }
  function fimDaBusca(t, falhou) {
    const b = buscas.get(t.chave) || { em: 0, falhaEm: 0 };
    if (falhou) b.falhaEm = Date.now();
    else {
      b.em = Date.now();
      b.falhaEm = 0;
      guardar('buscas', t.chave, { em: b.em });
    }
    buscas.set(t.chave, b);
    marcarEspecie(t.nome, t.moeda);
  }

  // ---- o que chega do gancho ---------------------------------------------------------------------------------------
  ouvir('rdm:conexao', (d) => {
    conectado = !!d.aberta;
    if (!conectado) emCurso = null;
  });
  ouvir('rdm:freio', (d) => {
    freadoAte = Number(d.ate) || Date.now() + 3 * MIN;
  });
  ouvir('rdm:catalogo', (lista) => {
    if (!Array.isArray(lista) || !lista.length) return;
    catalogo = lista;
    chrome.storage.local.set({ itensCatalogo: lista });
  });

  ouvir('rdm:vitrine', (d) => {
    conectado = true;
    const agora = Date.now();
    for (const l of Array.isArray(d.linhas) ? d.linhas : []) {
      const a = anuncioDe(l);
      if (!a) continue;
      const antes = vistos.get(a.id);
      const novo = antes ? antes.novo : a.criadoEm != null && agora - a.criadoEm < NOVO_MS;
      vistos.set(a.id, { a, em: agora, novo, avisado: antes ? antes.avisado && antes.a.preco === a.preco : false });
      paraAvaliar.add(a.id);
      garantirVendas(a, d.nossa ? 2 : 1); // o que a pessoa está olhando vem antes dos novos
    }
    agendarAvaliacao();
  });

  ouvir('rdm:vendas', (d) => {
    const mudou = new Set();
    // a busca é pelo nome e traz também espécies de nome parecido ("Tyranitar" traz "Mega Tyranitar"): todas ficam
    // guardadas, mas só as vendas da espécie pedida decidem se a busca já alcançou o que estava guardado
    const alvo = d.seq != null && emCurso && emCurso.seq === d.seq ? emCurso.tarefa : null;
    let conhecia = false;
    let maisAntiga = Infinity;
    for (const l of Array.isArray(d.linhas) ? d.linhas : []) {
      const v = vendaDe(l);
      if (!v) continue;
      const doAlvo = !!alvo && v.nome === alvo.nome;
      if (doAlvo) maisAntiga = Math.min(maisAntiga, v.em);
      const k = `${v.nome}|${v.moeda}`;
      let m = vendas.get(k);
      if (!m) vendas.set(k, (m = new Map()));
      if (m.has(v.id)) conhecia = conhecia || doAlvo;
      else {
        m.set(v.id, v);
        mudou.add(k);
      }
    }
    for (const k of mudou) guardar('vendas', k, [...vendas.get(k).values()]);
    if (!alvo) {
      // Tabela de preços que a própria pessoa abriu: as vendas ficam guardadas e os anúncios dessas espécies são revistos
      for (const k of mudou) marcarEspecie(...k.split('|'));
      return;
    }
    const t = alvo;
    emCurso = null;
    const acabou = d.falhou || !d.linhas.length || !d.temMais || conhecia || t.pagina + 1 >= t.limite || maisAntiga < Date.now() - JANELA_VENDAS_MS;
    if (acabou) fimDaBusca(t, d.falhou === true);
    else {
      // A 1ª página (30 vendas) já dá o veredito. As páginas seguintes só refinam: voltam para o fim da fila, depois
      // da 1ª página de todas as outras espécies, e a espécie já conta como buscada.
      const b = buscas.get(t.chave) || { em: 0, falhaEm: 0 };
      b.em = Date.now();
      buscas.set(t.chave, b);
      guardar('buscas', t.chave, { em: b.em });
      fila.push({ ...t, pagina: t.pagina + 1, prio: t.prio + 10, resto: true });
      marcarEspecie(t.nome, t.moeda);
    }
  });

  // resposta do gancho a um pedido: aceito (espera a resposta do jogo) ou recusado (tenta de novo mais tarde)
  const ESPERA_POR_MOTIVO = { cedo: 400, comprando: 3000, 'jogo-listando': 3000, esperando: 2000, teto: 5000, ocupada: 5000, 'sem-conexao': 5000, 'mercado-aberto': 20_000, freio: 30_000 };
  ouvir('rdm:pedido', (d) => {
    if (!emCurso || emCurso.ref !== d.ref) return;
    if (d.ok) {
      aceitos += 1;
      if (emCurso.tipo === 'vendas') emCurso.seq = d.seq;
      else emCurso = null; // recentes e itens: a resposta chega pelos ouvintes de cima
      return;
    }
    const e = emCurso;
    emCurso = null;
    if (d.motivo !== 'cedo') ultimaRecusa = { motivo: String(d.motivo), em: Date.now() };
    recusados += 1;
    proximoEm = Date.now() + (ESPERA_POR_MOTIVO[d.motivo] ?? 5000);
    if (e.tipo === 'vendas') {
      // pedido que o gancho nunca vai aceitar (nome estranho): desiste da busca em vez de tentar para sempre
      if (d.motivo === 'invalido') fimDaBusca(e.tarefa, true);
      else fila.unshift(e.tarefa);
    } else if (e.tipo === 'recentes') recentesEm = Date.now() - RECENTES_CADA_MS + (ESPERA_POR_MOTIVO[d.motivo] ?? 5000);
    else if (e.tipo === 'itens') itensEm = 0;
  });

  // Os anúncios de um item (do pedido da extensão ou da tela que a pessoa abriu): se o item tem regra de compra e há
  // anúncio no preço, o fundo decide a compra. Só os mais baratos seguem, sem nada de quem vende.
  // Os baratos quase sempre estão na retenção de 2 minutos e, quando liberam, vão a sorteio entre quem pediu logo
  // de cara: olhar a cada 20 s e só comprar o que já está livre chegava sempre tarde. Por isso, cada anúncio retido no
  // preço ganha uma compra marcada para quando libera (pela hora do servidor, +0,4 s), como o radar pessoal faz.
  const MARCAR_ATE_MS = 150_000;
  const estadoServe = (e) => !e || e === 'aberto' || /ret/i.test(String(e));
  ouvir('rdm:relogio', (d) => {
    if (Number.isFinite(d.diferenca) && Math.abs(d.diferenca) < 3_600_000) diferencaServidor = d.diferenca;
  });
  function mandarItem(itemId, moeda, linhas) {
    chrome.runtime.sendMessage({ tipo: 'itens-anuncios', itemId, moeda, linhas }).catch(() => {});
  }
  function marcarCompra(itemId, moeda, l) {
    if (comprasMarcadas.has(l.id)) return;
    const espera = l.compravelEm - diferencaServidor + 400 - Date.now();
    if (espera > MARCAR_ATE_MS) return; // a próxima olhada marca
    comprasMarcadas.set(
      l.id,
      setTimeout(() => {
        comprasMarcadas.delete(l.id);
        // a regra pode ter mudado (desligada, travada, preço menor) enquanto esperava
        const regra = regrasDeItens().find((r) => r.id === itemId && r.moeda === moeda);
        if (lider && regra && l.preco <= regra.precoMax) mandarItem(itemId, moeda, [{ ...l, compravelEm: null }]);
      }, Math.max(0, espera)),
    );
  }
  ouvir('rdm:item', (d) => {
    if (!lider) return;
    const moeda = d.moeda === 'gold' ? 'c' : 'g';
    const regra = regrasDeItens().find((r) => r.id === d.itemId && r.moeda === moeda);
    if (!regra) return;
    const agoraServidor = Date.now() + diferencaServidor;
    const linhas = (Array.isArray(d.linhas) ? d.linhas : [])
      .filter((l) => l && Number.isInteger(l.id) && l.preco > 0 && l.preco <= regra.precoMax && estadoServe(l.estado))
      .sort((x, y) => x.preco - y.preco)
      .slice(0, 10)
      .map((l) => ({ id: l.id, preco: l.preco, qtd: Math.max(1, Math.floor(l.qtd || 1)), compravelEm: l.compravelEm || null }));
    const livres = linhas.filter((l) => !l.compravelEm || l.compravelEm <= agoraServidor).map((l) => ({ ...l, compravelEm: null }));
    for (const l of linhas) if (l.compravelEm && l.compravelEm > agoraServidor) marcarCompra(d.itemId, moeda, l);
    if (livres.length) mandarItem(d.itemId, moeda, livres.slice(0, 5));
  });

  ouvir('rdm:itens', (d) => {
    const resumo = d.resumo || {};
    const medias = d.medias || {};
    // A tela do jogo pede o resumo filtrado (uma categoria, um elemento). Só o resumo inteiro, o do pedido da própria
    // extensão, troca a lista de itens e o câmbio; o filtrado só atualiza os itens que trouxe (antes, abrir "Pedras" no
    // jogo deixava a lista do menu só com as pedras).
    const inteiro = !!d.nossa;
    const positivo = (v) => (typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : null);
    // custos do motor: 10 unidades pela média de 7 dias em gemas (ou, sem ela, pelo menor anunciado)
    const novos = { ...custos };
    for (const [id, campo] of Object.entries(ITEM_DO_CUSTO)) {
      const unidade = positivo(medias[id] && medias[id].orb && medias[id].orb.media) ?? positivo(resumo[id] && resumo[id].minOrb);
      if (unidade != null) novos[campo] = Math.round(unidade * 10);
    }
    // câmbio coins/gema: a mediana, entre os itens vendidos nas duas moedas, de (menor em coins ÷ menor em gemas)
    const razoes = Object.values(resumo)
      .map((r) => (positivo(r.minOrb) >= 50 && positivo(r.minGold) ? r.minGold / r.minOrb : null))
      .filter((x) => x != null)
      .sort((x, y) => x - y);
    if (inteiro && razoes.length >= 3) novos.cambio = Math.round(razoes[Math.floor(razoes.length / 2)]);
    custos = novos;
    custosEm = Date.now();
    if (inteiro) itensEm = Date.now(); // o filtrado da tela não adia o pedido do resumo inteiro
    chrome.storage.local.set({ custosLocais: { em: custosEm, custos } });
    if (!Array.isArray(catalogo) || !catalogo.length) return; // sem o catálogo não há nome: fica só com os custos
    const nomes = new Map(catalogo.map((c) => [String(c.id), c]));
    const lista = [];
    for (const id of new Set([...Object.keys(resumo), ...Object.keys(medias)])) {
      const item = nomes.get(id);
      if (!item) continue;
      const r = resumo[id] || {};
      for (const moeda of ['gold', 'orb']) {
        if (moeda === 'orb' && soCoins(item.categoria)) continue;
        const menor = positivo(moeda === 'gold' ? r.minGold : r.minOrb);
        const media7d = positivo(medias[id] && medias[id][moeda] && medias[id][moeda].media);
        if (menor == null && media7d == null) continue;
        lista.push({ id: Number(id), nome: String(item.nome), cat: item.categoria || null, moeda: moeda === 'gold' ? 'c' : 'g', menor, media7d });
      }
    }
    const gravarLista = (final) => chrome.storage.local.set({ itens: final, itensEm: Date.now() }, () => chrome.runtime.sendMessage({ tipo: 'itens-novos' }).catch(() => {}));
    if (inteiro) return gravarLista(lista);
    if (!lista.length) return;
    chrome.storage.local.get(['itens'], (s) => {
      const novosDe = new Set(lista.map((x) => `${x.id}|${x.moeda}`));
      const antes = (Array.isArray(s.itens) ? s.itens : []).filter((x) => !novosDe.has(`${x.id}|${x.moeda}`));
      gravarLista([...antes, ...lista]);
    });
  });

  // ---- compra automática de itens: quais itens olhar ------------------------------------------------------------
  const itemVistoEm = new Map(); // "id|moeda" -> quando os anúncios do item foram pedidos pela última vez
  let ultimoItemEm = 0;
  /** as regras de compra de item, se a compra de itens está ligada e nada está travado */
  function regrasDeItens() {
    if (!regras.compraItensLigado || regras.travado || !Array.isArray(regras.compraItens)) return [];
    return regras.compraItens.filter((r) => r && Number.isInteger(r.id) && (r.moeda === 'g' || r.moeda === 'c') && r.precoMax > 0);
  }
  /** o item com regra há mais tempo sem ser olhado, se já passou o intervalo dele */
  function itemDaVez(agora) {
    if (agora - ultimoItemEm < ITEM_ESPACO_MS) return null;
    let escolhido = null;
    let maisVelho = Infinity;
    for (const r of regrasDeItens()) {
      const visto = itemVistoEm.get(`${r.id}|${r.moeda}`) || 0;
      if (agora - visto >= ITEM_CADA_MS && visto < maisVelho) {
        maisVelho = visto;
        escolhido = r;
      }
    }
    return escolhido;
  }

  // ---- o passo: um pedido por vez, no ritmo do gancho ------------------------------------------------------------
  function passo() {
    const agora = Date.now();
    if (emCurso) {
      if (agora - emCurso.em < SEM_RESPOSTA_MS) return;
      const e = emCurso; // sem resposta do jogo
      emCurso = null;
      semResposta += 1;
      if (e.tipo === 'vendas') fimDaBusca(e.tarefa, true);
    }
    if (!conectado || agora < proximoEm || agora < freadoAte) return;
    let tipo = null;
    let tarefa = null;
    const querItens = itensForcar || (agora - itensEm > ITENS_CADA_MS && ((regras.itens || []).length > 0 || agora - custosEm > CUSTOS_VALEM_MS));
    const item = lider ? itemDaVez(agora) : null;
    if (item) tipo = 'item';
    else if (lider && acompanhar && agora - recentesEm >= RECENTES_CADA_MS) tipo = 'recentes';
    else if (lider && querItens) tipo = 'itens';
    else if (fila.length) {
      fila.sort((x, y) => x.prio - y.prio);
      tarefa = fila.shift();
      tipo = 'vendas';
    }
    if (!tipo) return;
    emCurso = { ref: ++ref, tipo, tarefa, em: agora };
    proximoEm = agora + ENTRE_PEDIDOS_MS;
    if (tipo === 'item') {
      itemVistoEm.set(`${item.id}|${item.moeda}`, agora);
      ultimoItemEm = agora;
      pedir({ ref, tipo, itemId: item.id, moeda: item.moeda === 'c' ? 'gold' : 'orb' });
    } else if (tipo === 'recentes') {
      recentesEm = agora;
      pedir({ ref, tipo, moeda: moedaDaVez });
      moedaDaVez = moedaDaVez === 'orb' ? 'gold' : 'orb';
    } else if (tipo === 'itens') {
      itensForcar = false;
      itensEm = agora;
      pedir({ ref, tipo });
    } else {
      pedir({ ref, tipo, busca: tarefa.nome, moeda: tarefa.moeda, pagina: tarefa.pagina, soShiny: tarefa.classe === 's', soP5: tarefa.classe === '5' });
    }
  }

  // ---- avaliação ---------------------------------------------------------------------------------------------------
  function agendarAvaliacao() {
    if (avaliarTimer) return;
    avaliarTimer = setTimeout(() => {
      avaliarTimer = null;
      avaliarLote().catch((e) => console.error('[radar-mercado]', e));
    }, AVALIAR_EM_MS);
  }

  // As vendas da espécie parecidas com o Pokémon, com o mesmo critério do motor (preco.ts), para a lista e o número
  // baterem: mesmo shiny, mesma potência, Nota até 0,6 de distância, 30 dias. Na referência aproximada (largo), a do
  // motor quando a normal não acha 3 vendas: Nota até 0,9, 45 dias e também a potência vizinha (P1 a P4).
  function vendasParecidas(p, moeda, largo = false) {
    const m = vendas.get(`${p.nome}|${moeda}`);
    if (!m || p.nota == null) return [];
    const limite = Date.now() - (largo ? JANELA_VENDAS_MS : 30 * DIA);
    const janela = largo ? 0.9 : 0.6;
    const pot = p.potencia || 1;
    const potServe = (vp) => vp === pot || (largo && Math.abs(vp - pot) === 1 && vp < 5 && pot < 5);
    return [...m.values()]
      .filter((v) => v.em >= limite && v.shiny === !!p.shiny && potServe(v.pot) && v.nota != null && Math.abs(v.nota - p.nota) <= janela)
      .sort((x, y) => y.em - x.em);
  }
  // Dois grupos de preço: as vendas parecidas se dividem em um grupo barato e um caro, com um buraco de 3× ou mais
  // entre eles e pelo menos 3 vendas (e 20% do total) de cada lado. Nesse caso o "valor de mercado" fica no meio do
  // nada e engana; a etiqueta e a ficha avisam. Devolve [meio do grupo barato, meio do grupo caro] ou null.
  function doisGrupos(lista) {
    if (lista.length < 6) return null;
    const precos = lista.map((v) => v.preco).sort((x, y) => x - y);
    const minimo = Math.max(3, Math.ceil(precos.length * 0.2));
    let corte = -1;
    let maior = 3;
    for (let i = minimo; i <= precos.length - minimo; i++) {
      const razao = precos[i] / precos[i - 1];
      if (razao >= maior) {
        maior = razao;
        corte = i;
      }
    }
    if (corte < 0) return null;
    const meio = (xs) => xs[Math.floor(xs.length / 2)];
    return [meio(precos.slice(0, corte)), meio(precos.slice(corte))];
  }

  /** o que o motor precisa para avaliar: os anúncios vistos há pouco, as vendas guardadas e os custos */
  function contexto() {
    const agora = Date.now();
    const anuncios = [];
    for (const [id, v] of vistos) {
      if (agora - v.em > ANUNCIO_VALE_MS) vistos.delete(id);
      else anuncios.push(v.a);
    }
    const todas = [];
    const limite = agora - JANELA_VENDAS_MS;
    for (const m of vendas.values()) for (const v of m.values()) if (v.em >= limite) todas.push(v);
    const ctx = { anuncios, vendas: todas, custos, hub: null, agora };
    return { ctx, prep: M.preparar(ctx) };
  }

  // Quanto vale um Pokémon que não é um anúncio (a ficha aberta, o que a pessoa vai anunciar): busca as vendas da
  // espécie, se ainda não tem, e devolve o valor de mercado e a faixa. p: os campos do anúncio que o motor usa.
  async function avaliarAvulso(p, moeda) {
    const a = { ...p, id: -1, moeda, preco: 1, criadoEm: null, pokemonId: null, compravelEm: null, estado: 'aberto' };
    garantirVendas(a, 0); // quem está com a ficha aberta espera a resposta: vai na frente da fila
    const inicio = Date.now();
    while (buscaPendente(a) && Date.now() - inicio < 20_000) await new Promise((r) => setTimeout(r, 300));
    const { ctx, prep } = contexto();
    const r = await M.avaliar(a, ctx, prep);
    const mediana = r.mediana != null && r.n >= 3 ? Math.round(r.mediana) : null;
    const parecidas = vendasParecidas(a, moeda, !!r.refLarga);
    return {
      grupos: doisGrupos(parecidas),
      // as vendas parecidas mais recentes, para quem quer ver de onde saiu o número (sem nada de quem vendeu)
      parecidas: parecidas.slice(0, 10).map((v) => ({ preco: v.preco, nota: v.nota, nivel: v.nivel, pot: v.pot, em: v.em })),
      moeda, n: r.n || 0, mediana, p25: mediana != null && r.p25 != null ? Math.round(r.p25) : null, p75: mediana != null && r.p75 != null ? Math.round(r.p75) : null,
      aproximado: !!r.refLarga, liquido: mediana != null ? Math.round(M.liquidoVenda(mediana, moeda)) : null, pendente: buscaPendente(a), conectado,
    };
  }
  /** o anúncio do Mercado que é deste Pokémon (pelo número do Pokémon), se a extensão já o viu */
  function anuncioDoPokemon(pokemonId) {
    for (const v of vistos.values()) if (v.a.pokemonId != null && v.a.pokemonId === pokemonId) return { id: v.a.id, preco: v.a.preco, moeda: v.a.moeda };
    return null;
  }
  globalThis.RadarLocal = { avaliarAvulso, anuncioDoPokemon, liquido: (valor, moeda) => Math.round(M.liquidoVenda(valor, moeda)) };

  async function avaliarLote() {
    const ids = [...paraAvaliar];
    paraAvaliar.clear();
    if (!ids.length) return;
    const { ctx, prep } = contexto();
    const saida = {};
    const novos = [];
    for (const id of ids) {
      const v = vistos.get(id);
      if (!v) continue;
      let c;
      try {
        const r = await M.avaliar(v.a, ctx, prep);
        c = M.compactar(v.a, r);
        // a faixa onde ficou a maioria das vendas parecidas (o detalhe da etiqueta mostra)
        if (r.p25 != null && r.p75 != null) Object.assign(c, { q1: Math.round(r.p25), q3: Math.round(r.p75) });
        // quanto sobraria revendendo pelo preço de saída, já sem a taxa do Mercado (só quando sobra)
        if (r.revenda > 0) c.lu = Math.round(r.revenda);
        const grupos = doisGrupos(vendasParecidas(v.a, v.a.moeda, !!r.refLarga));
        if (grupos) c.g2 = grupos;
      } catch (e) {
        console.error('[radar-mercado] avaliar', e);
        continue;
      }
      c.t = v.em; // quando a extensão viu o anúncio pela última vez
      const pendente = buscaPendente(v.a);
      if (pendente) c.bu = 1; // ainda buscando as vendas desta espécie: a avaliação pode mudar
      saida[id] = c;
      if (v.novo && !v.avisado && !pendente) {
        v.avisado = true;
        novos.push(c);
      }
    }
    await gravar(saida);
    // só a aba líder avisa o fundo: com duas abas do jogo abertas, o alerta e a compra não saem em dobro
    if (novos.length && lider) chrome.runtime.sendMessage({ tipo: 'novos', anuncios: novos }).catch(() => {});
  }

  /** junta os avaliados ao que já está guardado, tira os velhos e grava (uma gravação por vez) */
  function gravar(saida) {
    gravando = gravando
      .then(() => chrome.storage.local.get(['anuncios']))
      .then(({ anuncios = {} }) => {
        const agora = Date.now();
        const mapa = {};
        // anúncio sem "t" veio do banco, da versão 1.x: sai na primeira gravação da 2.0
        for (const [id, a] of Object.entries(anuncios)) if (a && a.t && agora - a.t < ANUNCIO_VALE_MS) mapa[id] = a;
        Object.assign(mapa, saida);
        const chaves = Object.keys(mapa);
        if (chaves.length > MAX_ANUNCIOS) {
          chaves.sort((x, y) => mapa[x].t - mapa[y].t);
          for (const id of chaves.slice(0, chaves.length - MAX_ANUNCIOS)) delete mapa[id];
        }
        return chrome.storage.local.set({ anuncios: mapa, sincronizadoEm: agora, erro: null });
      })
      .catch((e) => console.error('[radar-mercado] gravar', e));
    return gravando;
  }

  function gravarEstado() {
    let nVendas = 0;
    for (const m of vendas.values()) nVendas += m.size;
    chrome.storage.local.set({
      local: {
        em: Date.now(), conectado, lider, especies: buscas.size, vendas: nVendas, freadoAte,
        fila: fila.filter((t) => !t.resto).length + (emCurso && emCurso.tipo === 'vendas' && !emCurso.tarefa.resto ? 1 : 0),
        refino: fila.filter((t) => t.resto).length, aceitos, recusados, semResposta, ultimaRecusa,
      },
    });
  }

  // ---- início ------------------------------------------------------------------------------------------------------
  function lerRegras(s) {
    regras = (s && s.regras) || {};
    acompanhar = !s || s.acompanharNovos !== false;
  }
  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local') return;
    if (mud.regras) regras = mud.regras.newValue || {};
    if (mud.acompanharNovos) acompanhar = mud.acompanharNovos.newValue !== false;
  });
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.tipo === 'local-itens') itensForcar = true; // o popup abriu o alerta de preço de item
    if (msg.tipo === 'local-agora') {
      recentesEm = 0; // "Atualizar agora": pede os recentes já e revê o que está na lista
      for (const id of vistos.keys()) paraAvaliar.add(id);
      agendarAvaliacao();
    }
  });

  chrome.storage.local.get(['regras', 'acompanharNovos', 'itensCatalogo', 'custosLocais'], async (s) => {
    lerRegras(s);
    if (Array.isArray(s.itensCatalogo) && s.itensCatalogo.length && !catalogo) catalogo = s.itensCatalogo;
    if (s.custosLocais && s.custosLocais.custos && Date.now() - s.custosLocais.em < 3 * DIA) {
      custos = { ...CUSTOS_PADRAO, ...s.custosLocais.custos };
      custosEm = s.custosLocais.em;
    }
    await carregar();
    // uma aba só fica de líder: é ela que pede os recentes e os itens e que avisa o fundo dos anúncios novos
    if (navigator.locks) navigator.locks.request('radar-mercado-lider', () => { lider = true; return new Promise(() => {}); }).catch(() => { lider = true; });
    else lider = true;
    setInterval(passo, PASSO_MS);
    setInterval(gravarEstado, 3000);
    setInterval(podarVendas, 6 * 3600_000);
    paraAvaliar.size && agendarAvaliacao();
  });
})();
