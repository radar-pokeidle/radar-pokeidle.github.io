// Radar de Mercado (extensão dos jogadores) — fundo: alertas, compra automática, apoiador e aviso de versão.
// Desde a 2.0 o fundo não busca mais os anúncios: quem lê o mercado (pela conexão do próprio jogo) e avalia é o
// local.js, na aba do jogo, que avisa aqui os anúncios NOVOS já avaliados ({ tipo: "novos" }).
// Alertas: anúncio novo que bate a regra vira notificação (ÓTIMO/EXCEPCIONAL para todos; regras sob medida para
// apoiadores). Alerta de preço de item (apoiadores): avisa quando o item chega no preço, com o resumo de itens que o
// local.js lê do jogo. Compra automática (para todos, desligada de fábrica): manda a compra para a aba do jogo, uma por
// vez, respeitando o teto por compra, o gasto e as compras do dia, a trava geral e a pausa de 30 min após 3 recusas.
// O nosso banco (Supabase) só é usado para conferir o código de apoiador e para a contagem anônima de uso; o site
// (GitHub Pages), para o aviso de versão nova. A chave publicável é pública por natureza, a mesma do JavaScript do site.
const SITE = 'https://radar-pokeidle.github.io';
const BANCO = 'https://vgxjjgqnwauhcghcrfvf.supabase.co';
const BANCO_CHAVE = 'sb_publishable_95GvkUYJq4Os80gWwAIC-A_ftuckIYB';
const CABECALHO_BANCO = { apikey: BANCO_CHAVE, Authorization: `Bearer ${BANCO_CHAVE}` };
const MINUTO = 60_000;
const FORMATO_CODIGO = /^RADAR[A-Z0-9]{16}$/;
const FORMATO_APARELHO = /^[0-9a-f-]{16,64}$/i;
const SINCRONIZA_MIN = 2; // o alarme de manutenção (compra sem resposta, versão nova, contagem de uso)
const JOGO_ABERTO_MS = 3 * MINUTO;
const VERIFICA_APOIO_MS = 6 * 3600_000;
const VERIFICA_VERSAO_MS = 24 * 3600_000;
const AVISO_VERSAO = 'versao-nova';
const MAX_ALERTAS_POR_VEZ = 5;
const SEM_RESPOSTA_MS = 60_000;
const RECUSAS_PARA_PAUSAR = 3;
const PAUSA_MS = 30 * MINUTO;
const ESPERA_RETIDO_MS = 5000;
const MAX_TENTATIVAS = 6;
const ORDEM = { excepcional: 5, otimo: 4, bom: 3, justo: 2, caro: 1, '?': 0 };
const NOME_VEREDITO = { excepcional: 'EXCEPCIONAL', otimo: 'ÓTIMO', bom: 'BOM', justo: 'JUSTO', caro: 'CARO' };

const REGRAS_PADRAO = {
  alertas: { ligado: false, vereditoMin: 'otimo', moedas: ['g'] },
  sobMedida: [], // [{ especie, notaMin, precoMax, moeda }]
  itens: [], // alerta de preço de item (apoiador): [{ id, nome, moeda, precoMax }]
  compra: { ligado: false, moeda: 'g', vereditoMin: 'otimo', precoMax: 3000, gastoDia: 10000, comprasDia: 3, especies: [] },
  travado: false,
};

let jogoVistoEm = 0;

const hoje = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
const n0 = (v) => Math.round(v).toLocaleString('pt-BR');
const notaDe = (a) => Number(String(a.k).split('|')[2]) / 100;
const nomeMoeda = (m) => (m === 'c' ? 'coins' : 'gemas');

async function ler(chaves) {
  return chrome.storage.local.get(chaves);
}

async function regras() {
  const { regras: r } = await ler(['regras']);
  return {
    ...REGRAS_PADRAO,
    ...(r || {}),
    alertas: { ...REGRAS_PADRAO.alertas, ...(r && r.alertas) },
    compra: { ...REGRAS_PADRAO.compra, ...(r && r.compra) },
  };
}

async function registrar(linha) {
  const { registro = [] } = await ler(['registro']);
  await chrome.storage.local.set({ registro: [{ em: Date.now(), ...linha }, ...registro].slice(0, 50) });
}

function notificar(titulo, texto) {
  chrome.notifications.create({ type: 'basic', iconUrl: 'icones/128.png', title: titulo, message: texto, priority: 1 }, () => void chrome.runtime.lastError);
}

// ---- apoiador: o código RADAR-… recebido ao apoiar (vale em até 2 navegadores) ---------------------------------------------
// O número fica também no armazenamento sincronizado do navegador: reinstalar a extensão (ou carregar a pasta de novo)
// apagava o local e sorteava outro, e o código de apoiador gastava uma vaga a cada vez. Uma promessa só, para duas
// conferências ao mesmo tempo não sortearem dois números.
let idEmCurso = null;
function idDoNavegador() {
  if (!idEmCurso) idEmCurso = lerOuSortearId().finally(() => { idEmCurso = null; });
  return idEmCurso;
}
async function lerOuSortearId() {
  const { aparelho } = await ler(['aparelho']);
  if (aparelho) {
    // instalação de antes da 2.0: leva o número para a sincronização, se ela ainda não tem um
    try { if (!(await chrome.storage.sync.get(['aparelho'])).aparelho) await chrome.storage.sync.set({ aparelho }); } catch { /* sem sincronização */ }
    return aparelho;
  }
  let doSync = null;
  try { doSync = (await chrome.storage.sync.get(['aparelho'])).aparelho || null; } catch { /* sem sincronização: fica só o local */ }
  const id = typeof doSync === 'string' && FORMATO_APARELHO.test(doSync) ? doSync : crypto.randomUUID(); // não identifica a pessoa
  await chrome.storage.local.set({ aparelho: id });
  try { await chrome.storage.sync.set({ aparelho: id }); } catch { /* idem */ }
  return id;
}

// o banco confere o código e conta os navegadores (até 2); devolve só se o apoio está ativo, nada da pessoa
async function conferirCodigo(bruto, aparelhoBruto) {
  const codigo = String(bruto || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!FORMATO_CODIGO.test(codigo)) return { valida: false, apoiador: false };
  const aparelho = typeof aparelhoBruto === 'string' && FORMATO_APARELHO.test(aparelhoBruto) ? aparelhoBruto : 'legado';
  const r = await fetch(`${BANCO}/rest/v1/rpc/radar_apoio_do_codigo`, {
    method: 'POST',
    headers: { ...CABECALHO_BANCO, 'Content-Type': 'application/json' },
    body: JSON.stringify({ p_codigo: codigo, p_aparelho: aparelho }),
    cache: 'no-store',
  });
  if (!r.ok) throw new Error(`banco respondeu ${r.status}`); // banco fora: vale a última resposta
  return (await r.json()) || {};
}

async function verificarApoio(forcar = false) {
  const { chaveApoio, apoio } = await ler(['chaveApoio', 'apoio']);
  if (!chaveApoio) {
    await chrome.storage.local.set({ apoio: { apoiador: false, verificadoEm: Date.now() } });
    return false;
  }
  if (!forcar && apoio && Date.now() - apoio.verificadoEm < VERIFICA_APOIO_MS) return apoio.apoiador;
  try {
    const j = await conferirCodigo(chaveApoio, await idDoNavegador());
    const novo = { apoiador: !!j.apoiador, valida: !!j.valida, plano: j.plano || null, motivo: j.motivo || null, verificadoEm: Date.now() };
    await chrome.storage.local.set({ apoio: novo });
    return novo.apoiador;
  } catch {
    return !!(apoio && apoio.apoiador); // sem internet agora: vale a última resposta
  }
}

// ---- contagem anônima de uso (desde a 1.5.9): 1 sinal por dia, só com o jogo aberto -------------------------------
// Manda só a versão da extensão; sem número de identificação e sem nada do jogo. O banco só soma navegadores por dia.
async function contarUsoDoDia() {
  const dia = hoje();
  const { usoContadoEm } = await ler(['usoContadoEm']);
  if (usoContadoEm === dia) return;
  try {
    const r = await fetch(`${BANCO}/rest/v1/rpc/radar_extensao_sinal`, {
      method: 'POST',
      headers: { ...CABECALHO_BANCO, 'Content-Type': 'application/json' },
      body: JSON.stringify({ p_versao: chrome.runtime.getManifest().version }),
      cache: 'no-store',
    });
    if (r.ok) await chrome.storage.local.set({ usoContadoEm: dia });
  } catch {
    /* sem internet agora: tenta de novo no próximo alarme */
  }
}

// ---- versão nova: fora da loja a extensão não se atualiza sozinha, então avisa (1 vez por dia confere) -----------
function maisNova(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0;
  }
  return false;
}

async function aplicarSelo() {
  const { versao } = await ler(['versao']);
  const nova = versao && versao.nova && maisNova(versao.nova, chrome.runtime.getManifest().version);
  await chrome.action.setBadgeBackgroundColor({ color: '#f0b93a' });
  await chrome.action.setBadgeText({ text: nova ? '↑' : '' });
}

async function verificarVersao(forcar = false) {
  const { versao } = await ler(['versao']);
  if (!forcar && versao && Date.now() - versao.checadaEm < VERIFICA_VERSAO_MS) return aplicarSelo();
  try {
    const r = await fetch(`${SITE}/extensao-versao.json`, { cache: 'no-store' });
    const j = await r.json();
    const valida = typeof j.versao === 'string' && /^\d+(\.\d+){0,3}$/.test(j.versao);
    const nova = valida && maisNova(j.versao, chrome.runtime.getManifest().version) ? j.versao : null;
    const novidades = nova ? String(j.novidades || '').slice(0, 200) : '';
    const avisada = versao && versao.avisada;
    await chrome.storage.local.set({ versao: { checadaEm: Date.now(), nova, novidades, avisada: nova || avisada || null } });
    if (nova && avisada !== nova) {
      chrome.notifications.create(
        AVISO_VERSAO,
        {
          type: 'basic',
          iconUrl: 'icones/128.png',
          title: `Radar de Mercado ${nova} disponível`,
          message: `${novidades ? `${novidades} ` : ''}Clique para ver como atualizar (2 minutos).`,
          priority: 1,
        },
        () => void chrome.runtime.lastError,
      );
    }
  } catch {
    /* sem internet agora: confere de novo na próxima vez */
  }
  return aplicarSelo();
}

// ---- alertas e compra para os anúncios novos -----------------------------------------------------------------
function bateSobMedida(a, r) {
  const nome = String(r.especie || '').trim().toLowerCase();
  return (
    (!nome || a.nome.toLowerCase() === nome) &&
    (r.notaMin == null || notaDe(a) >= r.notaMin) &&
    (r.precoMax == null || a.p <= r.precoMax) &&
    (!r.moeda || a.m === r.moeda)
  );
}

// Um lote de novos por vez: dois lotes ao mesmo tempo liam "nenhuma compra em andamento" juntos e mandavam duas
// compras (revisão de 24/11/2026). A fila garante uma compra por vez e a conta certa do gasto do dia.
let filaDeNovos = Promise.resolve();
function enfileirarNovos(novos) {
  filaDeNovos = filaDeNovos.then(() => tratarNovos(novos)).catch((e) => console.error('[radar-mercado] novos', e));
  return filaDeNovos;
}
/** só o que tem a cara de um anúncio avaliado (vem do local.js, mas o fundo confere antes de gastar) */
const anuncioValido = (a) =>
  !!a && Number.isInteger(a.id) && a.id > 0 && typeof a.nome === 'string' && typeof a.k === 'string' && typeof a.v === 'string' &&
  Number.isFinite(a.p) && a.p > 0 && (a.m === 'g' || a.m === 'c');

async function tratarNovos(novos) {
  const rg = await regras();
  const apoiador = await verificarApoio();
  const avisos = [];
  for (const a of novos) {
    const porVeredito = rg.alertas.ligado && rg.alertas.moedas.includes(a.m) && ORDEM[a.v] >= ORDEM[rg.alertas.vereditoMin];
    const porRegra = apoiador && rg.sobMedida.some((r) => bateSobMedida(a, r));
    if (porVeredito || porRegra) avisos.push(a);
  }
  for (const a of avisos.slice(0, MAX_ALERTAS_POR_VEZ)) {
    notificar(
      `${a.sh ? '✨ ' : ''}${a.nome} · ${NOME_VEREDITO[a.v] || String(a.v).toUpperCase()}`,
      `${n0(a.p)} ${nomeMoeda(a.m)}${a.vs != null ? ` (${a.vs > 0 ? '+' : ''}${a.vs}% vs mercado)` : ''} · Nv ${String(a.k).split('|')[0]} · nota ${notaDe(a).toFixed(2)}`,
    );
  }
  if (avisos.length > MAX_ALERTAS_POR_VEZ) notificar('Radar de Mercado', `E mais ${avisos.length - MAX_ALERTAS_POR_VEZ} anúncios que batem as suas regras.`);
  await tentarComprar(novos, rg);
}

// ---- alerta de preço de item (apoiador): o menor anunciado de cada item vem do resumo de itens do jogo -----------
// O local.js guarda a lista em "itens" ({ id, nome, moeda, menor, media7d }) e avisa aqui. Avisa quando o anúncio mais
// barato do item chega no preço da regra. Não repete o aviso enquanto o preço não cair mais; se o item sair do preço e
// voltar, avisa de novo. Não compra nada.
async function conferirItens() {
  const rg = await regras();
  const regrasItens = Array.isArray(rg.itens) ? rg.itens : [];
  if (!regrasItens.length || !(await verificarApoio())) return;
  const { itens: lista = [], itensAvisados = {} } = await ler(['itens', 'itensAvisados']);
  const avisados = {};
  for (const regra of regrasItens) {
    const it = lista.find((x) => x.id === regra.id && x.moeda === regra.moeda);
    if (!it || it.menor == null || !(regra.precoMax > 0) || it.menor > regra.precoMax) continue;
    const k = `${regra.id}|${regra.moeda}|${regra.precoMax}`;
    const ja = itensAvisados[k];
    avisados[k] = ja != null ? Math.min(ja, it.menor) : it.menor;
    if (ja == null || it.menor < ja) {
      notificar(
        `${regra.nome} a ${n0(it.menor)} ${nomeMoeda(regra.moeda)}`,
        `Chegou no seu preço (até ${n0(regra.precoMax)}).${it.media7d != null ? ` Média de 7 dias: ${n0(it.media7d)}.` : ''}`,
      );
    }
  }
  await chrome.storage.local.set({ itensAvisados: avisados });
}

// ---- compra automática -------------------------------------------------------------------------------------------
async function gastoDoDia(moeda) {
  const { gastos = {} } = await ler(['gastos']);
  return gastos[`${hoje()}|${moeda}`] || { valor: 0, compras: 0 };
}

function bateCompra(a, c) {
  const especies = (c.especies || []).map((e) => String(e).trim().toLowerCase()).filter(Boolean);
  return (
    a.m === c.moeda &&
    ORDEM[a.v] >= ORDEM[c.vereditoMin] &&
    a.p <= c.precoMax &&
    (!especies.length || especies.includes(a.nome.toLowerCase()))
  );
}

async function tentarComprar(novos, rg) {
  const c = rg.compra;
  const { emVoo, pausaAte = 0, abaJogo, tentados = [] } = await ler(['emVoo', 'pausaAte', 'abaJogo', 'tentados']);
  if (!c.ligado || rg.travado || Date.now() < pausaAte || abaJogo == null) return;
  if (emVoo && Date.now() - emVoo.em < SEM_RESPOSTA_MS) return; // uma compra por vez
  const g = await gastoDoDia(c.moeda);
  if (g.compras >= c.comprasDia) return;
  const escolha = novos
    .filter((a) => bateCompra(a, c) && !tentados.includes(a.id) && g.valor + a.p <= c.gastoDia)
    .sort((x, y) => (ORDEM[y.v] - ORDEM[x.v]) || ((y.i ?? 0) - (x.i ?? 0)))[0];
  if (!escolha) return;
  await enviarCompra(escolha, 0, abaJogo, tentados);
}

// ---- compra automática de ITENS (apoiador): o anúncio mais barato do item, até o preço e a quantidade da regra ----
// O local.js olha os anúncios de cada item com regra a cada 20 s e manda aqui os que estão no preço. Vale a mesma
// "uma compra por vez" dos Pokémon, a trava geral e a pausa depois de 3 recusas. O limite é por item: unidades por dia.
const ITEM_DE_NOVO_MS = 60_000; // anúncio que falhou agora só é tentado de novo depois disso
const ITEM_OCUPADO_MS = 1500; // outra compra em andamento: tenta de novo logo (o sorteio dura poucos segundos)
const ESPERA_RETIDO_ITEM_MS = 800;
async function comprarItem(m, vez = 0) {
  const rg = await regras();
  if (!rg.compraItensLigado || rg.travado || !(await verificarApoio())) return;
  const regra = (Array.isArray(rg.compraItens) ? rg.compraItens : []).find((r) => r && r.id === m.itemId && r.moeda === m.moeda);
  if (!regra || !(regra.precoMax > 0) || !(regra.qtdDia > 0)) return;
  const { emVoo, pausaAte = 0, abaJogo, gastosItens = {}, itensTentados = {} } = await ler(['emVoo', 'pausaAte', 'abaJogo', 'gastosItens', 'itensTentados']);
  const agora = Date.now();
  if (agora < pausaAte || abaJogo == null) return;
  if (emVoo && agora - emVoo.em < SEM_RESPOSTA_MS) {
    // uma compra por vez; a de item espera um pouco e tenta de novo, para não perder o sorteio que corre junto
    if (vez < 4) setTimeout(() => { filaDeNovos = filaDeNovos.then(() => comprarItem(m, vez + 1)).catch(() => {}); }, ITEM_OCUPADO_MS);
    return;
  }
  const ja = gastosItens[`${hoje()}|${regra.id}|${regra.moeda}`] || { qtd: 0, valor: 0 };
  const resta = Math.floor(regra.qtdDia - ja.qtd);
  if (resta < 1) return;
  const l = m.linhas
    .filter((x) => x.preco <= regra.precoMax && (!x.compravelEm || x.compravelEm <= agora) && !(itensTentados[x.id] > agora - ITEM_DE_NOVO_MS))
    .sort((x, y) => x.preco - y.preco)[0];
  if (!l) return;
  await enviarCompra({ id: l.id, p: l.preco, m: regra.moeda, nome: regra.nome, item: { id: regra.id, qtd: Math.min(l.qtd, resta) } }, 0, abaJogo, null);
}
const linhaDeItemValida = (x) => !!x && Number.isInteger(x.id) && x.id > 0 && Number.isFinite(x.preco) && x.preco > 0 && Number.isInteger(x.qtd) && x.qtd > 0;

async function enviarCompra(a, tentativa, abaJogo, tentados) {
  const { regras: r, itensTentados = {} } = await ler(['regras', 'itensTentados']);
  // a pessoa travou tudo ou desligou a compra no meio das tentativas: para aqui e libera a vez
  const desligada = a.item ? !(r && r.compraItensLigado) : !!(r && r.compra && r.compra.ligado === false);
  if ((r && r.travado) || desligada) {
    await chrome.storage.local.set({ emVoo: null });
    return;
  }
  const pedido = { id: a.id, preco: a.p, moeda: a.m === 'c' ? 'gold' : 'orb' };
  if (a.item) pedido.qtd = a.item.qtd; // preco é por unidade
  const agora = Date.now();
  await chrome.storage.local.set({
    emVoo: { ...pedido, nome: a.nome, m: a.m, em: agora, tentativa, a },
    ...(a.item
      ? { itensTentados: { ...Object.fromEntries(Object.entries(itensTentados).filter(([, em]) => em > agora - 10 * MINUTO)), [a.id]: agora } }
      : { tentados: [a.id, ...(tentados || [])].filter((x, i, l) => l.indexOf(x) === i).slice(0, 500) }),
  });
  if (tentativa === 0) await registrar({ acao: 'pedido', nome: a.item ? `${a.item.qtd}× ${a.nome}` : a.nome, preco: a.item ? a.p * a.item.qtd : a.p, m: a.m });
  chrome.tabs.sendMessage(abaJogo, { tipo: 'comprar', pedido }, () => {
    if (chrome.runtime.lastError) resultado({ tipo: 'sem-conexao', id: a.id }); // a aba do jogo fechou
  });
}

async function resultado(r) {
  const { emVoo, recusas = 0, abaJogo, tentados } = await ler(['emVoo', 'recusas', 'abaJogo', 'tentados']);
  if (!emVoo || (r.id != null && r.id !== emVoo.id)) return;
  if (r.tipo === 'sorteio') return; // entrou no sorteio de 3 s: espera o fim
  if (r.tipo === 'retido' && emVoo.tentativa < MAX_TENTATIVAS) {
    // ainda na retenção de 2 minutos: tenta de novo daqui a pouco
    // item: o anúncio libera em instantes e vai a sorteio, então tenta logo; Pokémon espera mais
    setTimeout(() => enviarCompra(emVoo.a, emVoo.tentativa + 1, abaJogo, tentados), emVoo.a && emVoo.a.item ? ESPERA_RETIDO_ITEM_MS : ESPERA_RETIDO_MS);
    return;
  }
  const item = emVoo.a && emVoo.a.item; // compra de item: { id, qtd }; o preço de emVoo é por unidade
  if (r.tipo === 'fim' && r.ok && item) {
    const { gastosItens = {} } = await ler(['gastosItens']);
    const dia = hoje();
    const chave = `${dia}|${item.id}|${emVoo.m}`;
    const g = gastosItens[chave] || { qtd: 0, valor: 0 };
    const total = emVoo.preco * item.qtd;
    // só os contadores de hoje ficam guardados
    const deHoje = Object.fromEntries(Object.entries(gastosItens).filter(([k]) => k.startsWith(`${dia}|`)));
    await chrome.storage.local.set({ emVoo: null, gastosItens: { ...deHoje, [chave]: { qtd: g.qtd + item.qtd, valor: g.valor + total } }, recusas: 0 });
    await registrar({ acao: 'comprado', nome: `${item.qtd}× ${emVoo.nome}`, preco: total, m: emVoo.m });
    notificar(`Comprado: ${item.qtd}× ${emVoo.nome}`, `${n0(total)} ${nomeMoeda(emVoo.m)} (${n0(emVoo.preco)} cada) · compra automática do Radar`);
    return;
  }
  if (r.tipo === 'fim' && r.ok) {
    // o gasto do dia entra na mesma gravação que libera a vez: a próxima compra já lê o gasto certo
    const { gastos = {} } = await ler(['gastos']);
    const chave = `${hoje()}|${emVoo.m}`;
    const g = gastos[chave] || { valor: 0, compras: 0 };
    await chrome.storage.local.set({ emVoo: null, gastos: { ...gastos, [chave]: { valor: g.valor + emVoo.preco, compras: g.compras + 1 } }, recusas: 0 });
    await registrar({ acao: 'comprado', nome: emVoo.nome, preco: emVoo.preco, m: emVoo.m });
    notificar(`Comprado: ${emVoo.nome}`, `${n0(emVoo.preco)} ${nomeMoeda(emVoo.m)} · compra automática do Radar`);
    return;
  }
  await chrome.storage.local.set({ emVoo: null });
  const info = r.perdeu ? 'perdeu o sorteio' : r.tipo === 'sem-conexao' ? 'jogo sem conexão' : r.tipo === 'sem-resposta' ? 'sem resposta' : r.tipo === 'freio' ? 'o jogo pediu para ir mais devagar' : r.msg || 'recusado';
  await registrar({ acao: 'não comprou', nome: emVoo.nome, preco: emVoo.preco, m: emVoo.m, info });
  // perder o sorteio, falta de conexão/resposta e o "devagar aí" não são recusa; só recusa do servidor conta para a pausa
  if (!r.perdeu && !['sem-conexao', 'sem-resposta', 'freio'].includes(r.tipo)) {
    const n = recusas + 1;
    if (n >= RECUSAS_PARA_PAUSAR) {
      await chrome.storage.local.set({ recusas: 0, pausaAte: Date.now() + PAUSA_MS });
      notificar('Radar: compra pausada 30 min', 'Três recusas seguidas do jogo. Confira o saldo e as regras.');
    } else await chrome.storage.local.set({ recusas: n });
  }
}

// compra que ficou sem resposta (aba fechou, mensagem perdida) não trava as próximas
async function limparSemResposta() {
  const { emVoo } = await ler(['emVoo']);
  if (emVoo && Date.now() - emVoo.em > SEM_RESPOSTA_MS) await resultado({ tipo: 'sem-resposta', id: emVoo.id });
}

// manda um recado ao local.js da aba do jogo (se ela estiver aberta)
async function paraAbaDoJogo(msg) {
  const { abaJogo } = await ler(['abaJogo']);
  if (abaJogo == null) return;
  await chrome.tabs.sendMessage(abaJogo, msg).catch(() => {});
}

// ---- eventos -------------------------------------------------------------------------------------------------------
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.remove(['coletor', 'coletorStatus']); // sobra do modo coletor, que saiu na 1.5.2
  chrome.storage.local.remove(['ate', 'completaEm']); // sobra da leitura do banco, que saiu na 2.0
  chrome.alarms.create('sincronizar', { periodInMinutes: SINCRONIZA_MIN });
  verificarVersao(true); // depois de atualizar, o selo de versão nova some
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('sincronizar', { periodInMinutes: SINCRONIZA_MIN });
  verificarVersao();
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== 'sincronizar') return;
  limparSemResposta();
  verificarVersao(); // só vai ao site uma vez por dia
  if (Date.now() - jogoVistoEm < JOGO_ABERTO_MS) contarUsoDoDia();
});

chrome.notifications.onClicked.addListener((id) => {
  if (id !== AVISO_VERSAO) return;
  chrome.tabs.create({ url: `${SITE}/extensao/#atualizar` });
  chrome.notifications.clear(id);
});

chrome.runtime.onMessage.addListener((msg, de, responder) => {
  if (!msg) return false;
  if (msg.tipo === 'jogo-aberto') {
    jogoVistoEm = Date.now();
    if (de.tab && de.tab.id != null) chrome.storage.local.set({ abaJogo: de.tab.id });
  } else if (msg.tipo === 'novos') {
    // anúncios novos, já avaliados pelo local.js na aba do jogo
    if (de.tab && Array.isArray(msg.anuncios)) enfileirarNovos(msg.anuncios.filter(anuncioValido).slice(0, 60));
  } else if (msg.tipo === 'itens-anuncios') {
    // anúncios de um item com regra de compra, já filtrados pelo preço (local.js); entra na mesma fila das compras
    const linhas = Array.isArray(msg.linhas) ? msg.linhas.filter(linhaDeItemValida).slice(0, 5) : [];
    if (de.tab && Number.isInteger(msg.itemId) && (msg.moeda === 'g' || msg.moeda === 'c') && linhas.length) {
      filaDeNovos = filaDeNovos.then(() => comprarItem({ itemId: msg.itemId, moeda: msg.moeda, linhas })).catch((e) => console.error('[radar-mercado] item', e));
    }
  } else if (msg.tipo === 'itens-novos') {
    conferirItens();
  } else if (msg.tipo === 'sincronizar-agora') {
    paraAbaDoJogo({ tipo: 'local-agora' }).then(() => responder(true));
    return true;
  } else if (msg.tipo === 'compra-resposta') {
    resultado(msg.r);
  } else if (msg.tipo === 'verificar-apoio') {
    verificarApoio(true).then((ok) => responder(ok));
    return true;
  } else if (msg.tipo === 'carregar-itens') {
    paraAbaDoJogo({ tipo: 'local-itens' }).then(() => responder(true));
    return true;
  }
  return false;
});
