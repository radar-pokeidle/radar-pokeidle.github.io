// Radar de Mercado (extensão dos jogadores) — janelinha do ícone: status, etiquetas, alertas, apoiador e compra.
const $ = (id) => document.getElementById(id);
const n0 = (v) => Math.round(v).toLocaleString('pt-BR');
const hoje = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
const numero = (el) => (el.value.trim() === '' ? null : Number(el.value));

// embutido na janela flutuante do jogo: avisa a altura para a janela acompanhar (abrir e fechar as seções)
if (new URLSearchParams(location.search).has('embutido')) {
  document.documentElement.classList.add('embutido');
  const avisarAltura = () => parent.postMessage({ rdmAltura: document.documentElement.scrollHeight }, 'https://pokeidle.io');
  new ResizeObserver(avisarAltura).observe(document.body);
}

function maisNova(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0;
  }
  return false;
}

// faixa de versão nova (o fundo confere no site uma vez por dia)
function mostrarVersao(versao) {
  const el = $('novaVersao');
  const atual = chrome.runtime.getManifest().version;
  if (!versao || !versao.nova || !maisNova(versao.nova, atual)) {
    el.hidden = true;
    return;
  }
  el.textContent = `↑ Versão ${versao.nova} disponível · atualizar`;
  const sub = document.createElement('small');
  sub.textContent = `Você está na ${atual}. Leva 2 minutos e não perde o código de apoiador nem as regras.`;
  el.appendChild(sub);
  el.hidden = false;
}

const PADRAO = {
  alertas: { ligado: false, vereditoMin: 'otimo', moedas: ['g'] },
  sobMedida: [],
  itens: [],
  compra: { ligado: false, moeda: 'g', vereditoMin: 'otimo', precoMax: 3000, gastoDia: 10000, comprasDia: 3, especies: [] },
  travado: false,
};

let regras = PADRAO;
let apoiador = false;
let itens = []; // [{ id, nome, moeda, menor, media7d }], do site
let pediuItens = false;

const salvarRegras = (r) => {
  regras = r;
  return chrome.storage.local.set({ regras: r });
};

function mostrarAlertas() {
  const lista = $('listaAlertas');
  lista.innerHTML = '';
  for (const [i, r] of regras.sobMedida.entries()) {
    const d = document.createElement('div');
    d.textContent = `${r.especie || 'qualquer'} · nota ≥ ${r.notaMin ?? '—'} · até ${r.precoMax != null ? n0(r.precoMax) : '—'} ${r.moeda === 'c' ? 'coins' : 'gemas'} `;
    const x = document.createElement('a');
    x.href = '#';
    x.textContent = 'tirar';
    x.style.color = '#ff7a7a';
    x.onclick = (e) => {
      e.preventDefault();
      salvarRegras({ ...regras, sobMedida: regras.sobMedida.filter((_, j) => j !== i) }).then(mostrarAlertas);
    };
    d.appendChild(x);
    lista.appendChild(d);
  }
}

// O que a aba do jogo está fazendo (desde a 2.0 quem avalia é o local.js, que guarda o seu estado em "local").
// Atualiza sozinho enquanto o menu está aberto, sem mexer nos campos que a pessoa está preenchendo.
const MOTIVO = {
  ocupada: 'a conexão do jogo está muito usada agora; o Radar espera a vez',
  teto: 'no limite de pedidos por minuto; continua em instantes',
  'sem-conexao': 'o jogo está sem conexão',
  'mercado-aberto': 'com o Mercado aberto, os anúncios novos esperam (recarregue a página do jogo para liberar)',
  comprando: 'esperando uma compra terminar',
};
function mostrarEstado(s) {
  $('total').textContent = Object.keys(s.anuncios || {}).length.toLocaleString('pt-BR');
  $('quando').textContent = s.sincronizadoEm ? new Date(s.sincronizadoEm).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '—';
  const lo = s.local && Date.now() - s.local.em < 30_000 ? s.local : null;
  const recusa = lo && lo.ultimaRecusa && Date.now() - lo.ultimaRecusa.em < 20_000 ? MOTIVO[lo.ultimaRecusa.motivo] : null;
  $('erro').textContent = s.erro
    ? `Não deu para atualizar: ${s.erro}`
    : !lo
      ? 'Abra o pokeidle.io: o Radar avalia os anúncios novos e os que você folhear no Mercado.'
      : lo.freadoAte > Date.now()
        ? 'O jogo pediu para ir mais devagar. O Radar volta a buscar vendas em alguns minutos.'
        : lo.fila > 0
          ? `Buscando as vendas de ${lo.fila} espécie${lo.fila === 1 ? '' : 's'} na Tabela de preços do jogo…${recusa ? ` (${recusa})` : ''}`
          : recusa || '';
  $('erro').title = lo
    ? `vendas guardadas: ${lo.vendas} · espécies buscadas: ${lo.especies} · pedidos aceitos: ${lo.aceitos} · recusados: ${lo.recusados} · sem resposta: ${lo.semResposta}${lo.lider ? '' : ' · outra aba do jogo é a principal'}`
    : '';
}
let estadoEm = 0;
chrome.storage.onChanged.addListener((mud, area) => {
  // outro bloco do menu (a compra de itens, em popup-itens.js) gravou as regras: este arquivo passa a salvar por cima
  // da versão nova, e não da cópia que leu ao abrir
  if (area === 'local' && mud.regras && mud.regras.newValue) regras = { ...regras, ...mud.regras.newValue };
  if (area !== 'local' || !(mud.local || mud.anuncios || mud.sincronizadoEm || mud.erro) || Date.now() - estadoEm < 1000) return;
  estadoEm = Date.now();
  chrome.storage.local.get(['anuncios', 'sincronizadoEm', 'erro', 'local'], mostrarEstado);
});

function mostrar() {
  chrome.storage.local.get(
    ['anuncios', 'sincronizadoEm', 'erro', 'etiquetasLigadas', 'regras', 'apoio', 'chaveApoio', 'gastos', 'registro', 'pausaAte', 'versao', 'itens', 'local'],
    (s) => {
      mostrarVersao(s.versao);
      regras = { ...PADRAO, ...(s.regras || {}), alertas: { ...PADRAO.alertas, ...(s.regras && s.regras.alertas) }, compra: { ...PADRAO.compra, ...(s.regras && s.regras.compra) } };
      apoiador = !!(s.apoio && s.apoio.apoiador);
      mostrarEstado(s);
      $('ligado').checked = s.etiquetasLigadas !== false;
      $('alertas').checked = regras.alertas.ligado;
      $('chave').value = s.chaveApoio || '';
      $('statusApoio').textContent = apoiador
        ? '· ativo ✓'
        : s.apoio && s.apoio.motivo === 'limite'
          ? '· este código já está em 2 navegadores'
          : s.chaveApoio
            ? '· código sem apoio ativo (venceu ou não existe)'
            : '';
      for (const id of ['caixaAlertas', 'caixaItens']) $(id).style.opacity = apoiador ? '1' : '0.55';
      itens = Array.isArray(s.itens) ? s.itens : [];
      preencherItens();
      mostrarItens();
      if (!itens.length && !pediuItens) {
        pediuItens = true;
        chrome.runtime.sendMessage({ tipo: 'carregar-itens' }, () => (chrome.runtime.lastError ? null : mostrar()));
      }
      const c = regras.compra;
      $('cLigado').checked = c.ligado;
      $('cMoeda').value = c.moeda;
      $('cVeredito').value = c.vereditoMin;
      $('cPreco').value = c.precoMax;
      $('cGasto').value = c.gastoDia;
      $('cCompras').value = c.comprasDia;
      $('cEspecies').value = (c.especies || []).join(', ');
      const g = (s.gastos || {})[`${hoje()}|${c.moeda}`] || { valor: 0, compras: 0 };
      const pausa = s.pausaAte && s.pausaAte > Date.now() ? ` · pausada até ${new Date(s.pausaAte).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : '';
      $('hoje').textContent = `${g.compras} compra(s) · ${n0(g.valor)} ${c.moeda === 'c' ? 'coins' : 'gemas'}${pausa}`;
      $('travar').textContent = regras.travado ? '🔓 Destravar as compras' : '🔒 Travar todas as compras';
      const reg = $('registro');
      reg.innerHTML = '';
      for (const l of (s.registro || []).slice(0, 15)) {
        const d = document.createElement('div');
        const hora = new Date(l.em).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        d.textContent = `${hora} · ${l.acao} · ${l.nome} · ${n0(l.preco)}${l.info ? ` · ${l.info}` : ''}`;
        reg.appendChild(d);
      }
      mostrarAlertas();
    },
  );
}

// ---- alerta de preço de item (apoiador) ----------------------------------------------------------------------------
const nomeMoeda = (m) => (m === 'c' ? 'coins' : 'gemas');
const itemDe = (id, moeda) => itens.find((x) => x.id === id && x.moeda === moeda) || null;

function mostrarPrecoDoItem() {
  const it = itemDe(Number($('iItem').value), $('iMoeda').value);
  $('iAgora').textContent = !itens.length
    ? 'carregando os itens…'
    : it && it.menor != null
      ? `agora ${n0(it.menor)}${it.media7d != null ? ` · média 7d ${n0(it.media7d)}` : ''}`
      : 'sem anúncio nesta moeda';
}

function preencherItens() {
  const sel = $('iItem');
  const antes = sel.value;
  const nomes = new Map(itens.map((x) => [x.id, x.nome]));
  sel.innerHTML = '';
  for (const [id, nome] of [...nomes].sort((a, b) => a[1].localeCompare(b[1]))) {
    const o = document.createElement('option');
    o.value = String(id);
    o.textContent = nome;
    sel.appendChild(o);
  }
  if (antes && nomes.has(Number(antes))) sel.value = antes;
  mostrarPrecoDoItem();
}

function mostrarItens() {
  const lista = $('listaItens');
  lista.innerHTML = '';
  for (const [i, r] of (regras.itens || []).entries()) {
    const d = document.createElement('div');
    const it = itemDe(r.id, r.moeda);
    d.textContent = `${r.nome} · até ${n0(r.precoMax)} ${nomeMoeda(r.moeda)}${it && it.menor != null ? ` (agora ${n0(it.menor)})` : ''} `;
    const x = document.createElement('a');
    x.href = '#';
    x.textContent = 'tirar';
    x.style.color = '#ff7a7a';
    x.onclick = (e) => {
      e.preventDefault();
      salvarRegras({ ...regras, itens: regras.itens.filter((_, j) => j !== i) }).then(mostrarItens);
    };
    d.appendChild(x);
    lista.appendChild(d);
  }
}

$('iItem').addEventListener('change', mostrarPrecoDoItem);
$('iMoeda').addEventListener('change', mostrarPrecoDoItem);
$('addItem').addEventListener('click', () => {
  if (!apoiador) {
    $('statusApoio').textContent = '· o alerta de preço de item é para apoiadores';
    $('caixaApoio').open = true;
    return;
  }
  const id = Number($('iItem').value);
  const moeda = $('iMoeda').value;
  const precoMax = numero($('iPreco'));
  const nome = (itens.find((x) => x.id === id) || {}).nome;
  if (!nome || !(precoMax > 0)) return;
  salvarRegras({ ...regras, itens: [...(regras.itens || []), { id, nome, moeda, precoMax }].slice(0, 20) }).then(() => {
    $('iPreco').value = '';
    mostrarItens();
    chrome.runtime.sendMessage({ tipo: 'carregar-itens' }, () => void chrome.runtime.lastError);
  });
});

$('ligado').addEventListener('change', (e) => chrome.storage.local.set({ etiquetasLigadas: e.target.checked }));
$('alertas').addEventListener('change', (e) => salvarRegras({ ...regras, alertas: { ...regras.alertas, ligado: e.target.checked } }));

$('salvarChave').addEventListener('click', () => {
  const chave = $('chave').value.trim();
  $('statusApoio').textContent = '· conferindo…';
  chrome.storage.local.set({ chaveApoio: chave }, () => chrome.runtime.sendMessage({ tipo: 'verificar-apoio' }, () => mostrar()));
});

$('addAlerta').addEventListener('click', () => {
  if (!apoiador) {
    $('statusApoio').textContent = '· as regras sob medida são para apoiadores';
    $('caixaApoio').open = true;
    return;
  }
  const r = { especie: $('aEspecie').value.trim(), notaMin: numero($('aNota')), precoMax: numero($('aPreco')), moeda: $('aMoeda').value };
  salvarRegras({ ...regras, sobMedida: [...regras.sobMedida, r].slice(0, 20) }).then(() => {
    $('aEspecie').value = '';
    $('aNota').value = '';
    $('aPreco').value = '';
    mostrarAlertas();
  });
});

$('salvarCompra').addEventListener('click', () => {
  const compra = {
    ligado: $('cLigado').checked,
    moeda: $('cMoeda').value,
    vereditoMin: $('cVeredito').value,
    precoMax: Math.max(1, numero($('cPreco')) ?? PADRAO.compra.precoMax),
    gastoDia: Math.max(1, numero($('cGasto')) ?? PADRAO.compra.gastoDia),
    comprasDia: Math.min(50, Math.max(1, numero($('cCompras')) ?? PADRAO.compra.comprasDia)),
    especies: $('cEspecies').value.split(',').map((x) => x.trim()).filter(Boolean),
  };
  salvarRegras({ ...regras, compra }).then(() => {
    $('salvarCompra').textContent = 'Salvo ✓';
    setTimeout(() => ($('salvarCompra').textContent = 'Salvar regras'), 1500);
    mostrar();
  });
});

$('travar').addEventListener('click', () => salvarRegras({ ...regras, travado: !regras.travado }).then(mostrar));

$('agora').addEventListener('click', () => {
  $('agora').textContent = 'Atualizando…';
  chrome.runtime.sendMessage({ tipo: 'sincronizar-agora' }, () => {
    $('agora').textContent = 'Atualizar agora';
    mostrar();
  });
});
mostrar();
