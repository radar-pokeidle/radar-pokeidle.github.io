// Radar de Mercado (extensão dos jogadores) — o Radar dentro de duas telas do jogo (2.0):
//  1. FICHA de qualquer Pokémon (seu ou de um anúncio): um quadro logo abaixo do bloco de cima, com quanto ele vale em
//     gemas e em coins, a faixa das vendas parecidas e quanto sobra depois da taxa do Mercado.
//  2. NOVO ANÚNCIO, na tela do preço: o valor de mercado na moeda escolhida, três botões que preenchem o campo de
//     preço (publicar continua com a pessoa) e o caminho para destacar o anúncio no Radar.
// Lê só o que já está escrito na tela (nome, nível, Nota, potência, qualidade, IV) e pede a avaliação ao local.js.
// Se o jogo mudar essas telas, o quadro simplesmente não aparece.
(function () {
  'use strict';
  const C = globalThis.RadarCartao;
  if (!C || globalThis.__rdmTelas) return;
  globalThis.__rdmTelas = true;
  const SITE = 'https://radar-pokeidle.github.io';
  const local = () => globalThis.RadarLocal || null;

  // ---- ler os números do jeito que o jogo escreve ------------------------------------------------------------------
  const inteiro = (t) => {
    const m = /(\d[\d.]*)/.exec(String(t || ''));
    return m ? Number(m[1].replace(/\./g, '')) : null;
  };
  const decimal = (t) => {
    const m = /(\d+(?:,\d+)?)/.exec(String(t || ''));
    return m ? Number(m[1].replace(',', '.')) : null;
  };
  const textoProprio = (el) => (el ? [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim() : '');
  const especieDe = (t) => String(t || '').replace(/^[^A-Za-zÀ-ÿ]+/, '').replace(/^Shiny\s+/i, '').trim();
  const ehShiny = (t) => /✨|^\s*Shiny\s/i.test(String(t || ''));

  function el(tag, estilo, texto) {
    const e = document.createElement(tag);
    if (estilo) e.style.cssText = estilo;
    if (texto != null) e.textContent = texto;
    return e;
  }
  const CAIXA = 'border:1px solid #57323f;border-radius:10px;background:#2a1820;color:#f6ece6;font:500 12px/1.45 system-ui,sans-serif;padding:8px 10px;text-align:left;';
  const APAGADO = 'color:#cdb3b6;font-size:11px;';

  /** "vale ~4.050 gemas (≈ R$ 235)" e, embaixo, a faixa, as vendas e o líquido */
  function blocoDeValor(r, semLiquido) {
    const d = el('div', 'margin-top:6px');
    const nome = C.moedaDe(r.moeda);
    if (r.mediana == null) {
      d.appendChild(el('div', 'font-weight:700', `Em ${nome}: sem preço de mercado`));
      d.appendChild(el('div', APAGADO, r.pendente ? 'O jogo ainda não respondeu as vendas desta espécie. Abra a ficha de novo em instantes.' : `Menos de 3 vendas parecidas nos últimos 45 dias (${r.n} achada${r.n === 1 ? '' : 's'}).`));
      return d;
    }
    const emReais = C.emGemas(r.moeda) ? ` (≈ ${C.reais(r.mediana)})` : '';
    d.appendChild(el('div', 'font-weight:700;font-size:13px', `Vale ~${C.n0(r.mediana)} ${nome}${emReais}`));
    const faixa = r.p25 && r.p75 && r.p75 > r.p25 ? `Vendas parecidas entre ${C.n0(r.p25)} e ${C.n0(r.p75)} · ` : '';
    d.appendChild(el('div', APAGADO, `${faixa}${C.vendas(r.n)}${r.aproximado ? ' (referência aproximada)' : ''}`));
    if (r.grupos) {
      d.appendChild(
        el('div', 'margin-top:3px;color:#f0b93a;font-size:11px', `Atenção: as vendas parecidas se dividem em dois grupos de preço, perto de ${C.n0(r.grupos[0])} e perto de ${C.n0(r.grupos[1])}. O valor acima fica entre os dois.`),
      );
    }
    if (Array.isArray(r.parecidas) && r.parecidas.length) {
      // de onde saiu o número: as vendas parecidas mais recentes, para quem quer conferir
      const det = el('details', 'margin-top:3px');
      const resumo = el('summary', APAGADO + 'cursor:pointer', r.n > r.parecidas.length ? `ver as ${r.parecidas.length} vendas parecidas mais recentes` : `ver as ${r.parecidas.length} vendas parecidas`);
      det.appendChild(resumo);
      det.appendChild(el('div', APAGADO + 'font-style:italic', 'O preço de cada venda como saiu. O valor acima acerta a diferença de Nota e de nível.'));
      const agora = Date.now();
      for (const v of r.parecidas) {
        const dias = Math.floor((agora - v.em) / 864e5);
        det.appendChild(el('div', APAGADO, `${C.n0(v.preco)} ${nome} · ${v.pot ? `P${v.pot} · ` : ''}Nota ${String(v.nota).replace('.', ',')} · Nv ${C.n0(v.nivel)} · ${dias < 1 ? 'hoje' : `há ${dias} dia${dias === 1 ? '' : 's'}`}`));
      }
      d.appendChild(det);
    }
    if (r.liquido != null && !semLiquido) d.appendChild(el('div', APAGADO, `Vendendo por esse valor, você recebe ~${C.n0(r.liquido)} ${nome} depois da taxa do Mercado.`));
    return d;
  }

  // ---- 1. a ficha ----------------------------------------------------------------------------------------------------
  function lerFicha(f) {
    const titulo = textoProprio(f.querySelector('.fi-nome'));
    const nome = especieDe(titulo);
    const nivel = inteiro((f.querySelector('.fi-nivel-chip') || {}).textContent);
    const nota = decimal((f.querySelector('.fi-nota-num') || {}).textContent);
    if (!nome || nivel == null || nota == null) return null;
    const ivs = {};
    for (const s of f.querySelectorAll('.fi-stat')) {
      const iv = s.querySelector('.fi-iv');
      const rotulo = ((s.querySelector('.fi-stat-nome') || {}).textContent || '').trim().toUpperCase();
      if (iv && rotulo) ivs[rotulo] = inteiro(iv.textContent);
    }
    const id = [...f.querySelectorAll('.txt-num')].map((e) => /^#(\d+)$/.exec(e.textContent.trim())).find(Boolean);
    return {
      pokemonId: id ? Number(id[1]) : null,
      dados: {
        nome, nivel, nota,
        potencia: inteiro((f.querySelector('.pk-selo-pot b') || {}).textContent),
        qualidade: decimal((f.querySelector('.pk-selo-q b') || {}).textContent),
        ivTotal: inteiro(textoProprio(f.querySelector('.pk-selo-iv b'))),
        hp: ivs.HP ?? null, atk: ivs.ATK ?? null, def: ivs.DEF ?? null, spAtk: ivs['SP.ATK'] ?? null, spDef: ivs['SP.DEF'] ?? null, speed: ivs.SPD ?? null,
        refino: inteiro((f.querySelector('.selo-refino') || {}).textContent) ?? 0,
        shiny: ehShiny(titulo) || !!f.querySelector('.fi-selos-linha .cm-selo-shiny'),
        tmAoe: !!f.querySelector('.fi-selos-linha .tm-selo.aoe'),
        tmZ: f.querySelector('.fi-selos-linha .tm-selo-cat') ? 'sim' : null,
      },
    };
  }

  const resultadosDaFicha = new Map(); // chave do Pokémon -> [resultado por moeda] (não recalcula ao reabrir)
  let chaveNaFicha = null;

  function desenharFicha(f, lido, resultados) {
    const heroi = f.querySelector('.fi-heroi');
    if (!heroi) return;
    let q = f.querySelector('#rdm-ficha');
    if (!q) {
      q = el('div', CAIXA + 'margin:8px 0;');
      q.id = 'rdm-ficha';
      heroi.insertAdjacentElement('afterend', q);
    }
    q.textContent = '';
    q.appendChild(el('div', 'font-weight:700;color:#f0b93a', 'Radar de Mercado · quanto vale'));
    if (!resultados) {
      q.appendChild(el('div', APAGADO + 'margin-top:4px', 'Buscando as vendas desta espécie na Tabela de preços do jogo…'));
      return;
    }
    const an = lido.pokemonId != null && local() ? local().anuncioDoPokemon(lido.pokemonId) : null;
    if (an) {
      const r = resultados.find((x) => x.moeda === an.moeda);
      const vs = r && r.mediana ? Math.round((an.preco / r.mediana - 1) * 100) : null;
      q.appendChild(el('div', 'margin-top:4px', `Anunciado por ${C.n0(an.preco)} ${C.moedaDe(an.moeda)}${vs != null ? `: ${C.contraMercado(vs, false)}` : ''}.`));
    }
    for (const r of resultados) q.appendChild(blocoDeValor(r));
    q.appendChild(el('div', APAGADO + 'margin-top:6px;color:#93767c', 'Estimativa pelas vendas reais do jogo, calculada no seu navegador. Não é garantia de lucro.'));
  }

  async function olharFicha() {
    const f = document.getElementById('ficha');
    if (!f || f.classList.contains('hidden') || !f.querySelector('.fi-heroi')) {
      chaveNaFicha = null;
      return;
    }
    const lido = lerFicha(f);
    if (!lido) return;
    const d = lido.dados;
    const chave = [lido.pokemonId, d.nome, d.nivel, d.nota, d.potencia, d.shiny].join('|');
    if (chave === chaveNaFicha && f.querySelector('#rdm-ficha')) return;
    chaveNaFicha = chave;
    const pronto = resultadosDaFicha.get(chave);
    desenharFicha(f, lido, pronto || null);
    if (pronto || !local()) return;
    // shiny só é vendido em gemas; os outros, nas duas moedas
    const moedas = d.shiny ? ['orb'] : ['orb', 'gold'];
    const resultados = [];
    for (const m of moedas) resultados.push(await local().avaliarAvulso(d, m));
    if (!resultados.some((r) => r.pendente)) resultadosDaFicha.set(chave, resultados);
    if (resultadosDaFicha.size > 60) resultadosDaFicha.delete(resultadosDaFicha.keys().next().value);
    if (chaveNaFicha === chave) desenharFicha(f, lido, resultados); // a pessoa ainda está nesta ficha
  }

  // ---- 2. novo anúncio: a tela do preço ----------------------------------------------------------------------------
  let escolhido = null; // o Pokémon que a pessoa clicou na lista de "Qual pokemon?"
  document.addEventListener(
    'click',
    (ev) => {
      const card = ev.target instanceof Element ? ev.target.closest('.cm-folha .cm-pk-escolha') : null;
      if (!card || ev.target.closest('.mk-ficha-btn')) return;
      const titulo = (card.querySelector('.mk-nome') || {}).textContent || '';
      const nome = especieDe(titulo);
      const nivel = inteiro((card.querySelector('.mk-sub') || {}).textContent);
      const nota = decimal(((card.querySelector('.pk-selo-n') || {}).textContent || '').replace(/^N\s*/, ''));
      if (!nome || nivel == null || nota == null) return;
      escolhido = {
        nome, nivel, nota,
        potencia: inteiro((card.querySelector('.cm-pot') || {}).textContent),
        qualidade: decimal(((card.querySelector('.pk-selo-q') || {}).textContent || '').replace(/^Q\s*/, '')),
        ivTotal: inteiro((card.querySelector('.pk-selo-iv') || {}).textContent),
        hp: null, atk: null, def: null, spAtk: null, spDef: null, speed: null, refino: 0,
        shiny: ehShiny(titulo), tmAoe: !!card.querySelector('.tm-selo.aoe'), tmZ: card.querySelector('.tm-selo-cat') ? 'sim' : null,
      };
    },
    true,
  );

  // A página de destaque do site lê a ficha no formato do "Copiar p/ ChatGPT" do jogo (números à inglesa: 1.579 é
  // decimal). Aqui vão só as linhas que ela usa para achar o anúncio; a pessoa confere e completa lá.
  function fichaParaOSite(p) {
    const ponto = (v) => (v == null ? '' : String(v));
    return [
      `# ${p.nome} — ficha do PokeIdle`,
      `Espécie: ${p.nome}`,
      `Shiny: ${p.shiny ? 'sim' : 'não'}`,
      `Nível: ${p.nivel}`,
      p.potencia != null ? `Potência: P${p.potencia}` : '',
      p.qualidade != null ? `Qualidade: ${ponto(p.qualidade)}` : '',
      p.ivTotal != null ? `IV somado: ${p.ivTotal}` : '',
      `Nota da Calculadora: ${ponto(p.nota)}`,
    ].filter(Boolean).join('\n');
  }

  function usarPreco(campo, valor) {
    // preenche o campo do jogo como se a pessoa tivesse digitado; publicar continua sendo com ela
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(campo, String(Math.max(1, Math.round(valor))));
    campo.dispatchEvent(new Event('input', { bubbles: true }));
    campo.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const resultadosDoAnuncio = new Map(); // "pokémon|moeda" -> resultado
  let chaveDoAnuncio = null;

  function desenharAnuncio(form, campo, r) {
    let q = form.querySelector('#rdm-anuncio');
    if (!q) {
      q = el('div', CAIXA + 'margin:8px 0;');
      q.id = 'rdm-anuncio';
      const moedas = form.querySelector('.cm-moedas');
      if (moedas) moedas.insertAdjacentElement('afterend', q);
      else form.appendChild(q);
    }
    q.textContent = '';
    q.appendChild(el('div', 'font-weight:700;color:#f0b93a', 'Radar de Mercado · preço sugerido'));
    if (!r) {
      q.appendChild(el('div', APAGADO + 'margin-top:4px', 'Buscando as vendas desta espécie na Tabela de preços do jogo…'));
      return;
    }
    q.appendChild(blocoDeValor(r, true)); // o recibo do jogo, logo abaixo, já mostra a taxa e o que a pessoa recebe
    if (r.mediana != null) {
      const linha = el('div', 'display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:8px');
      const opcoes = [
        ['Vender rápido', r.p25 && r.p25 < r.mediana ? r.p25 : Math.round(r.mediana * 0.9), 'um pouco abaixo do mercado, para sair logo'],
        ['Preço de mercado', r.mediana, 'o meio das vendas parecidas'],
        ['Esperar', r.p75 && r.p75 > r.mediana ? r.p75 : Math.round(r.mediana * 1.1), 'um pouco acima: pode demorar a vender'],
      ];
      for (const [rotulo, valor, explica] of opcoes) {
        const b = el('button', 'border:1px solid #57323f;border-radius:8px;background:#3a222d;color:#f6ece6;padding:5px 4px;cursor:pointer;font:600 11px/1.25 system-ui,sans-serif');
        b.type = 'button';
        b.title = `Preenche o preço com ${C.n0(valor)} (${explica}). Publicar continua com você.`;
        b.appendChild(el('div', '', rotulo));
        b.appendChild(el('div', 'color:#f0b93a', C.n0(valor)));
        b.addEventListener('click', () => usarPreco(campo, valor));
        linha.appendChild(b);
      }
      q.appendChild(linha);
    }
    const destaque = el('a', 'display:block;margin-top:8px;color:#f0b93a;font-weight:600;text-decoration:none', '★ Depois de publicar, destaque este anúncio no Radar →');
    destaque.href = `${SITE}/destaque/#ficha=${encodeURIComponent(fichaParaOSite(escolhido))}`;
    destaque.target = '_blank';
    destaque.rel = 'noopener';
    destaque.title = 'O anúncio em destaque aparece no topo do Mercado do Radar, na página inicial e no canto do jogo de quem usa a extensão.';
    q.appendChild(destaque);
  }

  async function olharAnuncio() {
    const campo = document.querySelector('.cm-folha #cm-preco');
    if (!campo) {
      chaveDoAnuncio = null;
      return;
    }
    const folha = campo.closest('.cm-folha');
    const form = campo.closest('.cm-form') || campo.parentElement;
    const naTela = especieDe((folha.querySelector('.dlg-ator-nome') || {}).textContent);
    if (!escolhido || !naTela || escolhido.nome !== naTela || !local()) return; // não dá para saber qual Pokémon é: fica sem o quadro
    const moeda = (folha.querySelector('.cm-moeda.on') || { dataset: {} }).dataset.moeda === 'orb' ? 'orb' : 'gold';
    const chave = [escolhido.nome, escolhido.nivel, escolhido.nota, escolhido.potencia, escolhido.shiny, moeda].join('|');
    if (chave === chaveDoAnuncio && form.querySelector('#rdm-anuncio')) return;
    chaveDoAnuncio = chave;
    const pronto = resultadosDoAnuncio.get(chave);
    desenharAnuncio(form, campo, pronto || null);
    if (pronto) return;
    const r = await local().avaliarAvulso(escolhido, moeda);
    if (!r.pendente) resultadosDoAnuncio.set(chave, r);
    if (resultadosDoAnuncio.size > 40) resultadosDoAnuncio.delete(resultadosDoAnuncio.keys().next().value);
    if (chaveDoAnuncio === chave) desenharAnuncio(form, campo, r);
  }

  // ---- olha a tela quando ela muda ---------------------------------------------------------------------------------
  let agendado = null;
  function agendar() {
    if (agendado) return;
    agendado = setTimeout(() => {
      agendado = null;
      olharFicha().catch((e) => console.error('[radar-mercado] ficha', e));
      olharAnuncio().catch((e) => console.error('[radar-mercado] anúncio', e));
    }, 150);
  }
  new MutationObserver((muts) => {
    if (muts.some((m) => !(m.target instanceof Element && m.target.closest('[id^="rdm-"], .rdm-etiqueta')))) agendar();
  }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  agendar();
})();
