// Radar de Mercado (extensão dos jogadores) — compra automática de ITENS no menu (apoiador).
// A pessoa escolhe o item numa lista (os mesmos do Mercado do jogo, por categoria), a moeda, o preço máximo por unidade
// e quantas unidades por dia. As regras ficam em regras.compraItens e a chave geral em regras.compraItensLigado; quem
// compra é o fundo.js. Este arquivo só cuida deste bloco do menu e não depende do popup.js.
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const n0 = (v) => (v == null ? '—' : Math.round(v).toLocaleString('pt-BR'));
  const nomeMoeda = (m) => (m === 'c' ? 'coins' : 'gemas');
  const CATEGORIAS = { fragment: 'Fragmentos', stone: 'Pedras', boss: 'Boss Tokens', loot: 'Boss Tokens', ticket: 'Tickets', casa: 'Casas', bicicleta: 'Bicicletas' };
  const ORDEM = ['Fragmentos', 'Pedras', 'Boss Tokens', 'Tickets', 'Casas', 'Bicicletas', 'Outros'];
  const MAX_REGRAS = 20;

  let regras = {};
  let itens = []; // [{ id, nome, cat, moeda, menor, media7d }], do resumo de itens do jogo (local.js)
  let gastos = {}; // "dia|id|moeda" -> { qtd, valor }
  let apoiador = false;

  const hoje = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
  const itemDe = (id, moeda) => itens.find((x) => x.id === id && x.moeda === moeda) || null;
  const lista = () => (Array.isArray(regras.compraItens) ? regras.compraItens : []);
  const salvar = (mudanca) => {
    regras = { ...regras, ...mudanca };
    return chrome.storage.local.set({ regras });
  };

  function preencherItens() {
    const sel = $('ciItem');
    const antes = sel.value;
    const porGrupo = new Map();
    const vistos = new Set();
    for (const x of itens) {
      if (vistos.has(x.id)) continue;
      vistos.add(x.id);
      const grupo = CATEGORIAS[x.cat] || 'Outros';
      if (!porGrupo.has(grupo)) porGrupo.set(grupo, []);
      porGrupo.get(grupo).push(x);
    }
    sel.textContent = '';
    for (const grupo of ORDEM) {
      const doGrupo = porGrupo.get(grupo);
      if (!doGrupo) continue;
      const og = document.createElement('optgroup');
      og.label = grupo;
      for (const x of doGrupo.sort((a, b) => a.nome.localeCompare(b.nome))) {
        const o = document.createElement('option');
        o.value = String(x.id);
        o.textContent = x.nome;
        og.appendChild(o);
      }
      sel.appendChild(og);
    }
    if (antes && vistos.has(Number(antes))) sel.value = antes;
    mostrarAgora();
  }

  function mostrarAgora() {
    const it = itemDe(Number($('ciItem').value), $('ciMoeda').value);
    $('ciAgora').textContent = !itens.length
      ? 'Abra o pokeidle.io para carregar a lista de itens do jogo.'
      : it && it.menor != null
        ? `Mais barato agora: ${n0(it.menor)} ${nomeMoeda(it.moeda)}${it.media7d != null ? ` · média de 7 dias: ${n0(it.media7d)}` : ''}`
        : 'Sem anúncio deste item nesta moeda agora.';
  }

  function mostrarLista() {
    const caixa = $('ciLista');
    caixa.textContent = '';
    const dia = hoje();
    lista().forEach((r, i) => {
      const d = document.createElement('div');
      const g = gastos[`${dia}|${r.id}|${r.moeda}`];
      const it = itemDe(r.id, r.moeda);
      d.textContent = `${r.nome} · até ${n0(r.precoMax)} ${nomeMoeda(r.moeda)} · ${g ? g.qtd : 0}/${r.qtdDia} hoje${it && it.menor != null ? ` (agora ${n0(it.menor)})` : ''} `;
      const x = document.createElement('a');
      x.href = '#';
      x.textContent = 'tirar';
      x.style.color = '#ff7a7a';
      x.onclick = (e) => {
        e.preventDefault();
        salvar({ compraItens: lista().filter((_, j) => j !== i) }).then(mostrarLista);
      };
      d.appendChild(x);
      caixa.appendChild(d);
    });
  }

  function mostrar() {
    $('ciLigado').checked = !!regras.compraItensLigado;
    $('caixaCompraItens').style.opacity = apoiador ? '1' : '0.55';
    preencherItens();
    mostrarLista();
  }

  function soApoiador() {
    if (apoiador) return true;
    const status = $('statusApoio');
    if (status) status.textContent = '· a compra automática de itens é para apoiadores';
    const caixa = $('caixaApoio');
    if (caixa) caixa.open = true;
    return false;
  }

  $('ciItem').addEventListener('change', mostrarAgora);
  $('ciMoeda').addEventListener('change', mostrarAgora);
  $('ciLigado').addEventListener('change', (e) => {
    if (e.target.checked && !soApoiador()) {
      e.target.checked = false;
      return;
    }
    salvar({ compraItensLigado: e.target.checked });
  });
  $('ciAdd').addEventListener('click', () => {
    if (!soApoiador()) return;
    const id = Number($('ciItem').value);
    const moeda = $('ciMoeda').value === 'c' ? 'c' : 'g';
    const precoMax = Number($('ciPreco').value);
    const qtdDia = Math.floor(Number($('ciQtd').value));
    const nome = (itens.find((x) => x.id === id) || {}).nome;
    if (!nome || !(precoMax > 0) || !(qtdDia > 0)) return;
    // um item por moeda: a regra nova troca a antiga
    const outras = lista().filter((r) => !(r.id === id && r.moeda === moeda));
    salvar({ compraItens: [...outras, { id, nome, moeda, precoMax, qtdDia }].slice(-MAX_REGRAS) }).then(() => {
      $('ciPreco').value = '';
      mostrarLista();
    });
  });

  // "Acompanhar os anúncios novos": ligado de fábrica; o local.js lê esta chave para pedir (ou não) os recentes
  $('acompanhar').addEventListener('change', (e) => chrome.storage.local.set({ acompanharNovos: e.target.checked }));

  function ler() {
    chrome.storage.local.get(['regras', 'itens', 'gastosItens', 'apoio', 'acompanharNovos'], (s) => {
      $('acompanhar').checked = s.acompanharNovos !== false;
      regras = s.regras || {};
      itens = Array.isArray(s.itens) ? s.itens : [];
      gastos = s.gastosItens || {};
      apoiador = !!(s.apoio && s.apoio.apoiador);
      mostrar();
      // sem a lista de itens ainda: pede ao jogo (a aba do pokeidle.io responde em instantes)
      if (!itens.length) chrome.runtime.sendMessage({ tipo: 'carregar-itens' }, () => void chrome.runtime.lastError);
    });
  }
  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local') return;
    if (mud.itens) itens = Array.isArray(mud.itens.newValue) ? mud.itens.newValue : [];
    if (mud.gastosItens) gastos = mud.gastosItens.newValue || {};
    if (mud.apoio) apoiador = !!(mud.apoio.newValue && mud.apoio.newValue.apoiador);
    if (mud.regras) regras = mud.regras.newValue || {};
    if (mud.itens) preencherItens();
    if (mud.itens || mud.gastosItens || mud.regras) mostrarLista();
    if (mud.apoio || mud.regras) {
      $('ciLigado').checked = !!regras.compraItensLigado;
      $('caixaCompraItens').style.opacity = apoiador ? '1' : '0.55';
    }
  });
  ler();
})();
